import SwiftUI

// MARK: - Buttons

struct PrimaryButton: View {
    let title: String
    var isLoading: Bool = false
    var isDisabled: Bool = false
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            ZStack {
                if isLoading {
                    ProgressView().tint(.white)
                } else {
                    Text(title)
                        .font(TAFont.body(15, weight: .bold))
                        .foregroundColor(.white)
                }
            }
            .frame(maxWidth: .infinity)
            .padding(.vertical, 16)
            .background(TAColor.primaryGradient)
            .clipShape(Capsule())
            .opacity(isDisabled ? 0.5 : 1)
        }
        .disabled(isDisabled || isLoading)
    }
}

struct SecondaryButton: View {
    let title: String
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            Text(title)
                .font(TAFont.body(14, weight: .semibold))
                .foregroundColor(TAColor.textPrimary)
                .frame(maxWidth: .infinity)
                .padding(.vertical, 15)
                .background(TAColor.surface)
                .clipShape(Capsule())
                .overlay(
                    Capsule().stroke(TAColor.divider, lineWidth: 1.2)
                )
        }
    }
}

// MARK: - Pills & badges

struct Pill: View {
    let text: String
    var color: Color = TAColor.primary
    var tint: Color = TAColor.primaryTint

    var body: some View {
        Text(text)
            .font(TAFont.caption)
            .foregroundColor(color)
            .padding(.horizontal, 10)
            .padding(.vertical, 5)
            .background(tint)
            .clipShape(Capsule())
    }
}

enum ParticipantStatusStyle {
    static func badge(for status: ParticipantStatus) -> some View {
        switch status {
        case .pending:
            return Pill(text: "Pending approval", color: TAColor.warning, tint: TAColor.warningTint)
        case .accepted:
            return Pill(text: "Confirmed", color: TAColor.success, tint: TAColor.successTint)
        case .rejected:
            return Pill(text: "Not accepted", color: TAColor.danger, tint: TAColor.dangerTint)
        }
    }
}

// MARK: - Avatars

struct AvatarView: View {
    let initials: String
    var size: CGFloat = 34
    var url: String? = nil

    var body: some View {
        ZStack {
            Circle().fill(TAColor.primaryGradient)
            Text(initials)
                .font(.system(size: size * 0.38, weight: .bold, design: .rounded))
                .foregroundColor(.white)
        }
        .frame(width: size, height: size)
        .overlay(Circle().stroke(TAColor.background, lineWidth: 2))
    }
}

struct AvatarStack: View {
    let initials: [String]
    var size: CGFloat = 30
    var maxShown: Int = 3

    var body: some View {
        HStack(spacing: -10) {
            ForEach(Array(initials.prefix(maxShown).enumerated()), id: \.offset) { _, i in
                AvatarView(initials: i, size: size)
            }
            if initials.count > maxShown {
                ZStack {
                    Circle().fill(TAColor.surfaceHigh)
                    Text("+\(initials.count - maxShown)")
                        .font(.system(size: size * 0.34, weight: .bold))
                        .foregroundColor(TAColor.textSecondary)
                }
                .frame(width: size, height: size)
                .overlay(Circle().stroke(TAColor.background, lineWidth: 2))
            }
        }
    }
}

/// Trust ring — the signature element. Only used around an organiser's avatar
/// on the activity detail screen, so it reads as a real trust signal.
struct TrustRingAvatar: View {
    let initials: String
    var size: CGFloat = 52

    var body: some View {
        Circle()
            .strokeBorder(
                AngularGradient(colors: [TAColor.primary, TAColor.primaryDark, TAColor.primary], center: .center),
                lineWidth: 2.5
            )
            .frame(width: size, height: size)
            .overlay(AvatarView(initials: initials, size: size - 6))
    }
}

/// Maps an activity's category to a bundled illustration asset (see
/// Assets.xcassets) so card thumbnails show real artwork, not empty
/// gradient blocks. Falls back to the "Other" illustration for anything
/// unrecognized (e.g. a custom category string).
enum CategoryIcon {
    static func imageName(for category: String) -> String {
        switch category {
        case "Sports": return "cat_sports"
        case "Outdoors": return "cat_outdoors"
        case "Food & Coffee": return "cat_food"
        case "Games": return "cat_games"
        case "Books": return "cat_books"
        case "Wellness": return "cat_wellness"
        default: return "cat_other"
        }
    }
}

// MARK: - Activity card

struct ActivityCardView: View {
    let activity: Activity
    var goingInitials: [String] = []
    var goingCount: Int = 0

    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            ZStack(alignment: .topLeading) {
                if let urlString = activity.coverImageURL, let url = URL(string: urlString) {
                    AsyncImage(url: url) { phase in
                        switch phase {
                        case .success(let image):
                            image.resizable().aspectRatio(contentMode: .fill)
                        default:
                            Image(CategoryIcon.imageName(for: activity.category))
                                .resizable()
                                .aspectRatio(contentMode: .fill)
                        }
                    }
                    .frame(height: 110)
                    .clipped()
                } else {
                    Image(CategoryIcon.imageName(for: activity.category))
                        .resizable()
                        .aspectRatio(contentMode: .fill)
                        .frame(height: 110)
                        .clipped()
                }
                Pill(text: activity.category)
                    .padding(10)
            }

            VStack(alignment: .leading, spacing: 6) {
                Text(activity.title)
                    .font(TAFont.cardTitle)
                    .foregroundColor(TAColor.textPrimary)
                    .lineLimit(2)

                Text(activity.scheduleSummary)
                    .font(TAFont.body(12.5))
                    .foregroundColor(TAColor.textMuted)

                HStack {
                    HStack(spacing: 6) {
                        AvatarStack(initials: goingInitials, size: 24, maxShown: 3)
                        Text("\(goingCount) going")
                            .font(TAFont.body(11.5, weight: .semibold))
                            .foregroundColor(TAColor.textSecondary)
                    }
                    Spacer()
                    Text(activity.spotsRemaining > 0 ? "\(activity.spotsRemaining) spots left" : "Full · waitlist")
                        .font(TAFont.body(11.5, weight: .bold))
                        .foregroundColor(activity.spotsRemaining > 0 ? TAColor.primary : TAColor.textMuted)
                }
                .padding(.top, 4)
            }
            .padding(14)
        }
        .background(TAColor.surface)
        .clipShape(RoundedRectangle(cornerRadius: TARadius.md))
    }
}

// MARK: - Empty state

struct EmptyStateView: View {
    let icon: String
    let title: String
    let message: String

    var body: some View {
        VStack(spacing: TASpacing.md) {
            Image(systemName: icon)
                .font(.system(size: 30))
                .foregroundColor(TAColor.textMuted)
                .frame(width: 64, height: 64)
                .background(TAColor.surface)
                .clipShape(Circle())
            Text(title)
                .font(TAFont.subtitle)
                .foregroundColor(TAColor.textPrimary)
            Text(message)
                .font(TAFont.body(13))
                .foregroundColor(TAColor.textMuted)
                .multilineTextAlignment(.center)
                .padding(.horizontal, 40)
        }
        .frame(maxWidth: .infinity)
        .padding(.top, 60)
    }
}

// MARK: - Inline text field

struct TAField: View {
    let label: String
    var placeholder: String = ""
    @Binding var text: String
    var isSecure: Bool = false

    var body: some View {
        VStack(alignment: .leading, spacing: 6) {
            Text(label)
                .font(TAFont.body(12.5, weight: .semibold))
                .foregroundColor(TAColor.textSecondary)
            Group {
                if isSecure {
                    SecureField(placeholder, text: $text)
                } else {
                    TextField(placeholder, text: $text)
                }
            }
            .font(TAFont.body(14.5))
            .foregroundColor(TAColor.textPrimary)
            .padding(14)
            .background(TAColor.surface)
            .clipShape(RoundedRectangle(cornerRadius: TARadius.sm))
            .overlay(RoundedRectangle(cornerRadius: TARadius.sm).stroke(TAColor.divider, lineWidth: 1))
        }
    }
}
