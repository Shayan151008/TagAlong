import Foundation

struct PexelsPhoto: Identifiable, Decodable, Equatable {
    let id: Int
    let photographer: String
    let photographerURL: String
    let src: PexelsPhotoSrc

    enum CodingKeys: String, CodingKey {
        case id, photographer
        case photographerURL = "photographer_url"
        case src
    }
}

struct PexelsPhotoSrc: Decodable, Equatable {
    let medium: String
    let large: String
    let tiny: String
}

private struct PexelsSearchResponse: Decodable {
    let photos: [PexelsPhoto]
}

enum PexelsError: Error {
    case missingAPIKey
}

final class PexelsService {
    static let shared = PexelsService()
    private init() {}

    /// Searches Pexels for free, commercially-licensed stock photos.
    /// Returns [] (rather than throwing) on network failure so a picker UI
    /// can just show an empty state instead of crashing a form.
    func search(query: String) async throws -> [PexelsPhoto] {
        guard PexelsConfig.apiKey != "Uie41OuLDQI4TWrrMPEsxEcF8D2V1VUfR40NOTbWs3aiUUod7QfAlYV8", !PexelsConfig.apiKey.isEmpty else {
            throw PexelsError.missingAPIKey
        }
        var components = URLComponents(string: "https://api.pexels.com/v1/search")!
        components.queryItems = [
            URLQueryItem(name: "query", value: query),
            URLQueryItem(name: "per_page", value: "20"),
            URLQueryItem(name: "orientation", value: "landscape"),
        ]
        var request = URLRequest(url: components.url!)
        // Pexels expects the raw API key in this header — no "Bearer" prefix.
        request.setValue(PexelsConfig.apiKey, forHTTPHeaderField: "Authorization")

        let (data, _) = try await URLSession.shared.data(for: request)
        let decoded = try JSONDecoder().decode(PexelsSearchResponse.self, from: data)
        return decoded.photos
    }
}
