import Foundation
import Supabase

final class ActivityService {
    static let shared = ActivityService()
    private var client: SupabaseClient { SupabaseManager.shared.client }

    /// Browse activities, newest date first. `accepted_count` is expected to come
    /// from a Postgres view (see Supabase/schema.sql: activities_with_counts).
    func fetchNearby(category: String? = nil, neighbourhood: String? = nil) async throws -> [Activity] {
        var query = client
            .from("activities_with_counts")
            .select()

        if let category, category != "All" {
            query = query.eq("category", value: category)
        }
        if let neighbourhood, !neighbourhood.isEmpty {
            query = query.ilike("location", pattern: "%\(neighbourhood)%")
        }

        return try await query
            .order("date", ascending: true)
            .execute()
            .value
    }

    func fetchActivity(id: UUID) async throws -> Activity {
        try await client
            .from("activities_with_counts")
            .select()
            .eq("id", value: id)
            .single()
            .execute()
            .value
    }

    func fetchGoing(activityId: UUID) async throws -> [Profile] {
        // Requires the accepted_participants_with_profile view — see schema.sql
        try await client
            .from("accepted_participants_with_profile")
            .select()
            .eq("activity_id", value: activityId)
            .execute()
            .value
    }

    func createActivity(_ input: NewActivityInput, organiserId: UUID) async throws {
        try await client
            .from("activities")
            .insert(input.asInsertPayload(organiserId: organiserId))
            .execute()
    }

    func fetchHosted(by organiserId: UUID) async throws -> [Activity] {
        try await client
            .from("activities_with_counts")
            .select()
            .eq("organiser_id", value: organiserId)
            .order("date", ascending: true)
            .execute()
            .value
    }
}

/// Plain input struct for the create-activity form, kept separate from `Activity`
/// so the form doesn't need id/organiser/counts before submission.
struct NewActivityInput {
    var title: String = ""
    var category: String = ActivityCategory.outdoors.rawValue
    var date: Date = Date()
    var time: Date = Date()
    var location: String = ""
    var maxParticipants: Int = 8
    var description: String = ""
    var coverImageURL: String? = nil

    var isValid: Bool {
        !title.trimmingCharacters(in: .whitespaces).isEmpty &&
        !location.trimmingCharacters(in: .whitespaces).isEmpty &&
        maxParticipants > 1
    }

    func asInsertPayload(organiserId: UUID) -> [String: AnyJSON] {
        let dateFmt = DateFormatter(); dateFmt.dateFormat = "yyyy-MM-dd"
        let timeFmt = DateFormatter(); timeFmt.dateFormat = "HH:mm"

        var payload: [String: AnyJSON] = [
            "organiser_id": .string(organiserId.uuidString),
            "title": .string(title),
            "description": .string(description),
            "category": .string(category),
            "date": .string(dateFmt.string(from: date)),
            "time": .string(timeFmt.string(from: time)),
            "location": .string(location),
            "max_participants": .double(Double(maxParticipants))
        ]
        if let coverImageURL {
            payload["cover_image_url"] = .string(coverImageURL)
        }
        return payload
    }
}
