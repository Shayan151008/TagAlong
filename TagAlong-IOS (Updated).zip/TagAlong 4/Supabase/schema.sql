-- TagAlong MVP schema
-- Run in the Supabase SQL editor. Assumes Supabase Auth is already enabled.

-- =========================================================
-- 1. PROFILES
-- =========================================================
create table if not exists profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text not null,
  bio text,
  avatar_url text,
  location text,
  interests text[],
  created_at timestamptz not null default now()
);

alter table profiles enable row level security;

create policy "Profiles are viewable by any authenticated user"
  on profiles for select
  to authenticated
  using (true);

create policy "Users can insert their own profile"
  on profiles for insert
  to authenticated
  with check (auth.uid() = id);

create policy "Users can update their own profile"
  on profiles for update
  to authenticated
  using (auth.uid() = id);


-- =========================================================
-- 2. ACTIVITIES
-- =========================================================
create table if not exists activities (
  id uuid primary key default gen_random_uuid(),
  organiser_id uuid not null references profiles(id) on delete cascade,
  title text not null,
  description text not null default '',
  category text not null,
  date date not null,
  time time not null,
  location text not null,
  latitude double precision,
  longitude double precision,
  max_participants int not null check (max_participants > 1),
  cover_image_url text,
  created_at timestamptz not null default now()
);

-- Safe to re-run: adds the column if you ran an earlier version of this
-- schema before cover_image_url existed.
alter table activities add column if not exists cover_image_url text;

alter table activities enable row level security;

create policy "Activities are viewable by any authenticated user"
  on activities for select
  to authenticated
  using (true);

create policy "Users can create their own activities"
  on activities for insert
  to authenticated
  with check (auth.uid() = organiser_id);

create policy "Organisers can update their own activities"
  on activities for update
  to authenticated
  using (auth.uid() = organiser_id);

create policy "Organisers can delete their own activities"
  on activities for delete
  to authenticated
  using (auth.uid() = organiser_id);


-- =========================================================
-- 3. ACTIVITY PARTICIPANTS (join requests)
-- =========================================================
create table if not exists activity_participants (
  id uuid primary key default gen_random_uuid(),
  activity_id uuid not null references activities(id) on delete cascade,
  user_id uuid not null references profiles(id) on delete cascade,
  status text not null default 'pending' check (status in ('pending', 'accepted', 'rejected')),
  requested_at timestamptz not null default now(),
  responded_at timestamptz,
  unique (activity_id, user_id)
);

alter table activity_participants enable row level security;

-- A requester can see their own requests; an organiser can see requests
-- for activities they host.
create policy "View own requests or requests for own activities"
  on activity_participants for select
  to authenticated
  using (
    auth.uid() = user_id
    or auth.uid() in (select organiser_id from activities where activities.id = activity_id)
  );

create policy "Users can request to join as themselves"
  on activity_participants for insert
  to authenticated
  with check (auth.uid() = user_id);

-- Only the organiser of the related activity can accept/reject.
create policy "Organisers can respond to requests on their activities"
  on activity_participants for update
  to authenticated
  using (auth.uid() in (select organiser_id from activities where activities.id = activity_id));


-- =========================================================
-- 4. SAFETY: REPORTS & BLOCKS
-- =========================================================
create table if not exists reports (
  id uuid primary key default gen_random_uuid(),
  reporter_id uuid not null references profiles(id) on delete cascade,
  reported_user_id uuid not null references profiles(id) on delete cascade,
  activity_id uuid references activities(id) on delete set null,
  reason text not null,
  created_at timestamptz not null default now()
);

alter table reports enable row level security;

create policy "Users can file their own reports"
  on reports for insert
  to authenticated
  with check (auth.uid() = reporter_id);

create policy "Users can view their own filed reports"
  on reports for select
  to authenticated
  using (auth.uid() = reporter_id);


create table if not exists blocks (
  id uuid primary key default gen_random_uuid(),
  blocker_id uuid not null references profiles(id) on delete cascade,
  blocked_id uuid not null references profiles(id) on delete cascade,
  created_at timestamptz not null default now(),
  unique (blocker_id, blocked_id)
);

alter table blocks enable row level security;

create policy "Users manage their own block list"
  on blocks for all
  to authenticated
  using (auth.uid() = blocker_id)
  with check (auth.uid() = blocker_id);


-- =========================================================
-- 5. VIEWS used by the app (keep client queries simple)
-- =========================================================

-- Activities with a live accepted-participant count.
create or replace view activities_with_counts as
select
  a.*,
  coalesce(p.accepted_count, 0) as accepted_count,
  greatest(a.max_participants - coalesce(p.accepted_count, 0), 0) as spots_remaining
from activities a
left join (
  select activity_id, count(*) as accepted_count
  from activity_participants
  where status = 'accepted'
  group by activity_id
) p on p.activity_id = a.id;

-- Accepted participants joined with their profile, for the "who's going" list.
create or replace view accepted_participants_with_profile as
select
  pr.id, pr.full_name, pr.bio, pr.avatar_url, pr.location, pr.interests, pr.created_at,
  ap.activity_id
from activity_participants ap
join profiles pr on pr.id = ap.user_id
where ap.status = 'accepted';

-- Join requests joined with the requester's profile and the activity's organiser,
-- for the host-side "Join Requests" screen.
create or replace view participants_with_requester as
select
  ap.id, ap.activity_id, ap.user_id, ap.status, ap.requested_at, ap.responded_at,
  pr.full_name as "requesterName",
  upper(left(split_part(pr.full_name, ' ', 1), 1) || coalesce(left(split_part(pr.full_name, ' ', 2), 1), '')) as "requesterInitials",
  a.organiser_id
from activity_participants ap
join profiles pr on pr.id = ap.user_id
join activities a on a.id = ap.activity_id;

-- Blocked users joined with the blocked person's profile, for Settings.
create or replace view blocked_users_with_profile as
select
  b.blocker_id,
  pr.id,
  pr.full_name
from blocks b
join profiles pr on pr.id = b.blocked_id;
