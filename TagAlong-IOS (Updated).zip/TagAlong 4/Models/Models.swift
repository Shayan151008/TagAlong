import Foundation

// MARK: - Profile

struct Profile: Codable, Identifiable, Equatable {
    let id: UUID
    var fullName: String
    var bio: String?
    var avatarUrl: String?
    var location: String?
    var interests: [String]?
    var createdAt: Date?

    enum CodingKeys: String, CodingKey {
        case id
        case fullName = "full_name"
        case bio
        case avatarUrl = "avatar_url"
        case location
        case interests
        case createdAt = "created_at"
    }

    var initials: String {
        let parts = fullName.split(separator: " ")
        let letters = parts.prefix(2).compactMap { $0.first }
        return String(letters).uppercased()
    }
}

// MARK: - Activity

struct Activity: Codable, Identifiable, Equatable {
    let id: UUID
    var organiserId: UUID
    var title: String
    var description: String
    var category: String
    var date: String       // "yyyy-MM-dd"
    var time: String       // "HH:mm"
    var location: String
    var latitude: Double?
    var longitude: Double?
    var maxParticipants: Int
    var acceptedCount: Int?
    var coverImageURL: String?
    var createdAt: Date?

    enum CodingKeys: String, CodingKey {
        case id
        case organiserId = "organiser_id"
        case title, description, category, date, time, location, latitude, longitude
        case maxParticipants = "max_participants"
        case acceptedCount = "accepted_count"
        case coverImageURL = "cover_image_url"
        case createdAt = "created_at"
    }

    var spotsRemaining: Int {
        max(maxParticipants - (acceptedCount ?? 0), 0)
    }

    var scheduleSummary: String {
        "\(Self.friendlyDate(date)) · \(time) · \(location)"
    }

    static func friendlyDate(_ raw: String) -> String {
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy-MM-dd"
        guard let d = formatter.date(from: raw) else { return raw }
        let out = DateFormatter()
        out.dateFormat = "EEE, d MMM"
        return out.string(from: d)
    }
}

enum ActivityCategory: String, CaseIterable, Identifiable {
    case sports = "Sports"
    case outdoors = "Outdoors"
    case food = "Food & Coffee"
    case games = "Games"
    case books = "Books"
    case wellness = "Wellness"
    case other = "Other"

    var id: String { rawValue }
}

// MARK: - Activity participants (join requests)

enum ParticipantStatus: String, Codable {
    case pending, accepted, rejected
}

struct ActivityParticipant: Codable, Identifiable, Equatable {
    let id: UUID
    var activityId: UUID
    var userId: UUID
    var status: ParticipantStatus
    var requestedAt: Date?
    var respondedAt: Date?

    // Populated via join query when listing requests for a host
    var requesterName: String?
    var requesterInitials: String?

    enum CodingKeys: String, CodingKey {
        case id
        case activityId = "activity_id"
        case userId = "user_id"
        case status
        case requestedAt = "requested_at"
        case respondedAt = "responded_at"
        case requesterName
        case requesterInitials
    }
}

/// A row for "My Activities" — an activity plus the viewer's relationship to it.
struct MyActivityRow: Identifiable, Equatable {
    let activity: Activity
    let myStatus: ParticipantStatus?   // nil if the viewer is the organiser
    var id: UUID { activity.id }
}

// MARK: - Safety

struct Report: Codable {
    var reporterId: UUID
    var reportedUserId: UUID
    var activityId: UUID?
    var reason: String

    enum CodingKeys: String, CodingKey {
        case reporterId = "reporter_id"
        case reportedUserId = "reported_user_id"
        case activityId = "activity_id"
        case reason
    }
}

struct BlockedUser: Codable, Identifiable, Equatable {
    let id: UUID           // blocked user's id
    var fullName: String
}
