import Foundation

/// Fill these in from your Supabase project settings (Project Settings > API).
/// For a real build, move these into an .xcconfig / environment-based setup
/// instead of hardcoding — never commit the service_role key into the app.
enum SupabaseConfig {
    static let url = URL(string: "https://uyyfnafsnunpskoarfyv.supabase.co"")!
    static let anonKey = "sb_publishable_yBia5X9E1I_CRkCgrdvrfA_TwScx_fs"
}

/// Free key from https://www.pexels.com/api/ — 200 requests/hour, 20,000/month,
/// no cost. Used to let organisers search real stock photos for their
/// activity's cover image instead of a fixed built-in list.
enum PexelsConfig {
    static let apiKey = "Uie41OuLDQI4TWrrMPEsxEcF8D2V1VUfR40NOTbWs3aiUUod7QfAlYV8"
}
