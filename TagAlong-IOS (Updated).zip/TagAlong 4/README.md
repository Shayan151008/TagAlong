# TagAlong — iOS (SwiftUI + Supabase)

MVP build matching the locked scope: auth, profile setup, browse/filter activities,
activity detail with organiser trust card, request-to-join, host-side join request
approval, My Activities dashboard, profile, and safety (report/block). No chat,
ratings, recommendation engine, or social feed — by design, not by omission.

## 1. Create the Xcode project

1. Open Xcode → **File → New → Project → iOS → App**.
2. Product name: `TagAlong`. Interface: **SwiftUI**. Language: **Swift**.
3. Delete the generated `ContentView.swift` and default `App` file.
4. Drag the `App`, `Config`, `DesignSystem`, `Models`, `Services`, and `Features`
   folders from this delivery into your Xcode project (check "Copy items if needed"
   and "Create groups").

## 2. Add the Supabase Swift package

**File → Add Package Dependencies…** and add:

```
https://github.com/supabase/supabase-swift
```

Add the **Supabase** product to your app target (this pulls in Auth, Postgrest,
Realtime, and Storage as a single umbrella module, which is all this MVP needs).

## 3. Set up your Supabase project

1. Create a project at [supabase.com](https://supabase.com).
2. In the SQL Editor, run everything in `Supabase/schema.sql`. This creates the
   `profiles`, `activities`, `activity_participants`, `reports`, and `blocks`
   tables, their row-level security policies, and the helper views the app
   queries against. Already ran an earlier version of this schema? Just
   re-run it — the `cover_image_url` column addition is idempotent.
3. In **Project Settings → API**, copy your Project URL and anon public key into
   `Config/SupabaseConfig.swift`.
4. In **Authentication → Providers**, email/password is enabled by default —
   nothing else to turn on for this MVP.

## 4. Set up cover photo search (Pexels)

The "Host an activity" screen lets organisers search real stock photos for
their activity's cover image instead of a fixed built-in set.

1. Get a free key at [pexels.com/api](https://www.pexels.com/api/) — instant
   signup, no cost, 200 requests/hour and 20,000/month on the free tier.
2. Paste it into `PexelsConfig.apiKey` in `Config/SupabaseConfig.swift`.

If you skip this, the app still works — activity cards just fall back to the
built-in category illustration (soccer ball, coffee cup, etc.) instead of a
searched photo.

## 5. Run it

Build and run on a simulator or device. First launch: Welcome → Sign Up →
Profile Setup → Explore.

## Notes on scope and follow-ups

- **Cover photos** search Pexels live rather than using a fixed curated list —
  this covers your "pickleball, football, movie, restaurant, etc." use case
  for any search term, not just ones I hardcoded. Falls back to the built-in
  category illustration (`Assets.xcassets`) if the organiser skips picking one,
  or if no Pexels key is configured.
- **Auth** is email/password only for MVP speed. Apple/Google sign-in and phone
  OTP are natural next steps but add real setup overhead (Apple Developer
  entitlements, SMS provider) — intentionally left out for now.
- **Notifications** ("user receives notification" in the core flow) aren't wired
  to push yet. The accept/reject flow updates `activity_participants.status`
  immediately, so the simplest first step is polling that on the dashboard;
  Supabase Realtime or APNs can layer on top later without changing the schema.
- **Location filtering** currently does a text match on `location` plus a
  category filter — no live GPS radius search yet. `activities` already has
  `latitude`/`longitude` columns ready for a PostGIS-backed radius query when
  you want that.
- All Supabase calls assume `supabase-swift` v2's `SupabaseClient` API
  (`client.auth`, `client.from(...)`). If you're pinned to an older version,
  the call shapes may differ slightly.
