import SwiftUI

struct CoverPhotoPicker: View {
    @Environment(\.dismiss) private var dismiss
    let initialQuery: String
    let onSelect: (PexelsPhoto) -> Void

    @State private var query: String = ""
    @State private var photos: [PexelsPhoto] = []
    @State private var isLoading = false
    @State private var errorMessage: String?

    private let columns = [GridItem(.flexible(), spacing: 10), GridItem(.flexible(), spacing: 10)]

    var body: some View {
        NavigationStack {
            ZStack {
                TAColor.background.ignoresSafeArea()
                VStack(spacing: TASpacing.md) {
                    HStack(spacing: TASpacing.sm) {
                        Image(systemName: "magnifyingglass").foregroundColor(TAColor.textMuted)
                        TextField("Search photos — try \"pickleball\", \"movie night\"", text: $query, onCommit: { Task { await search() } })
                            .foregroundColor(TAColor.textPrimary)
                        Button("Search") { Task { await search() } }
                            .font(TAFont.body(13, weight: .bold))
                            .foregroundColor(TAColor.primary)
                    }
                    .padding(12)
                    .background(TAColor.surface)
                    .clipShape(RoundedRectangle(cornerRadius: TARadius.sm))
                    .padding(.horizontal, TASpacing.lg)
                    .padding(.top, TASpacing.sm)

                    if isLoading {
                        Spacer()
                        ProgressView().tint(TAColor.primary)
                        Spacer()
                    } else if let errorMessage {
                        Spacer()
                        EmptyStateView(icon: "photo.badge.exclamationmark", title: "Couldn't load photos", message: errorMessage)
                        Spacer()
                    } else if photos.isEmpty {
                        Spacer()
                        EmptyStateView(icon: "photo.on.rectangle", title: "Search for a cover photo", message: "Try the activity type — \"badminton\", \"coffee shop\", \"board games\".")
                        Spacer()
                    } else {
                        ScrollView {
                            LazyVGrid(columns: columns, spacing: 10) {
                                ForEach(photos) { photo in
                                    Button {
                                        onSelect(photo)
                                        dismiss()
                                    } label: {
                                        AsyncImage(url: URL(string: photo.src.medium)) { phase in
                                            switch phase {
                                            case .success(let image):
                                                image.resizable().aspectRatio(contentMode: .fill)
                                            default:
                                                Rectangle().fill(TAColor.surface)
                                            }
                                        }
                                        .frame(height: 110)
                                        .clipShape(RoundedRectangle(cornerRadius: TARadius.sm))
                                    }
                                }
                            }
                            .padding(.horizontal, TASpacing.lg)

                            Text("Photos provided by Pexels")
                                .font(TAFont.caption)
                                .foregroundColor(TAColor.textMuted)
                                .padding(.vertical, TASpacing.lg)
                        }
                    }
                }
            }
            .navigationTitle("Choose a cover photo")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Cancel") { dismiss() }
                }
            }
            .task {
                query = initialQuery
                await search()
            }
        }
    }

    private func search() async {
        guard !query.trimmingCharacters(in: .whitespaces).isEmpty else { return }
        isLoading = true
        errorMessage = nil
        do {
            photos = try await PexelsService.shared.search(query: query)
            if photos.isEmpty {
                errorMessage = "No results for \"\(query)\". Try a different search."
            }
        } catch PexelsError.missingAPIKey {
            errorMessage = "Add a free Pexels API key in Config/SupabaseConfig.swift to enable photo search."
        } catch {
            errorMessage = "Something went wrong. Check your connection and try again."
        }
        isLoading = false
    }
}
