import SwiftUI

@MainActor
final class AuthFormViewModel: ObservableObject {
    @Published var email = ""
    @Published var password = ""
    @Published var errorMessage: String?
    @Published var isLoading = false

    func signUp() async {
        await run { try await AuthService.shared.signUp(email: self.email, password: self.password) }
    }

    func signIn() async {
        await run { try await AuthService.shared.signIn(email: self.email, password: self.password) }
    }

    private func run(_ action: @escaping () async throws -> Void) async {
        errorMessage = nil
        isLoading = true
        do {
            try await action()
        } catch {
            print("Auth error: \(error)")   // TEMP — check Xcode's debug console for the real message
            errorMessage = "Something went wrong. Check your details and try again."
        }
        isLoading = false
    }
}

struct WelcomeView: View {
    @State private var showSignUp = false
    @State private var showLogin = false

    var body: some View {
        ZStack {
            TAColor.background.ignoresSafeArea()
            VStack(spacing: TASpacing.lg) {
                Spacer()

                RoundedRectangle(cornerRadius: TARadius.lg)
                    .fill(LinearGradient(colors: [TAColor.primaryTint, TAColor.surfaceHigh], startPoint: .top, endPoint: .bottom))
                    .frame(height: 200)
                    .overlay(
                        Image(systemName: "figure.2.and.child.holdinghands")
                            .font(.system(size: 46))
                            .foregroundColor(TAColor.primary)
                    )

                VStack(alignment: .leading, spacing: TASpacing.sm) {
                    Text("Say yes to the plan\nyou'd usually skip.")
                        .font(TAFont.display(24))
                        .foregroundColor(TAColor.textPrimary)
                    Text("See who's hosting, who's going, and why — before you ever show up.")
                        .font(TAFont.body(14))
                        .foregroundColor(TAColor.textSecondary)
                }
                .frame(maxWidth: .infinity, alignment: .leading)

                Spacer()

                PrimaryButton(title: "Get started") { showSignUp = true }
                SecondaryButton(title: "I already have an account") { showLogin = true }
            }
            .padding(TASpacing.xl)
        }
        .sheet(isPresented: $showSignUp) { SignUpView() }
        .sheet(isPresented: $showLogin) { LoginView() }
    }
}

struct SignUpView: View {
    @StateObject private var vm = AuthFormViewModel()
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        ZStack {
            TAColor.background.ignoresSafeArea()
            VStack(alignment: .leading, spacing: TASpacing.lg) {
                Text("Create your account")
                    .font(TAFont.screenTitle)
                    .foregroundColor(TAColor.textPrimary)

                TAField(label: "Email", placeholder: "you@example.com", text: $vm.email)
                    .textInputAutocapitalization(.never)
                TAField(label: "Password", placeholder: "At least 8 characters", text: $vm.password, isSecure: true)

                if let error = vm.errorMessage {
                    Text(error).font(TAFont.caption).foregroundColor(TAColor.danger)
                }

                PrimaryButton(title: "Continue", isLoading: vm.isLoading) {
                    Task { await vm.signUp() }
                }

                Spacer()
            }
            .padding(TASpacing.xl)
        }
    }
}

struct LoginView: View {
    @StateObject private var vm = AuthFormViewModel()
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        ZStack {
            TAColor.background.ignoresSafeArea()
            VStack(alignment: .leading, spacing: TASpacing.lg) {
                Text("Welcome back")
                    .font(TAFont.screenTitle)
                    .foregroundColor(TAColor.textPrimary)

                TAField(label: "Email", placeholder: "you@example.com", text: $vm.email)
                    .textInputAutocapitalization(.never)
                TAField(label: "Password", placeholder: "Your password", text: $vm.password, isSecure: true)

                if let error = vm.errorMessage {
                    Text(error).font(TAFont.caption).foregroundColor(TAColor.danger)
                }

                PrimaryButton(title: "Log in", isLoading: vm.isLoading) {
                    Task { await vm.signIn() }
                }

                Spacer()
            }
            .padding(TASpacing.xl)
        }
    }
}
