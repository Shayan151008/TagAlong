# TagAlong — Flutter (iOS + Android)

Same MVP scope and dark/violet design as the SwiftUI build, rewritten in Dart so
one codebase ships to both iOS and Android (and web, if you ever want it).
No chat, ratings, recommendation engine, or social feed — by design.

## 1. Install Flutter

```
brew install --cask flutter
flutter doctor
```

Follow whatever `flutter doctor` tells you to fix (Xcode command-line tools,
CocoaPods, Android Studio/SDK, etc). You need a Mac with Xcode installed to
build the iOS target — that's an Apple requirement, not a Flutter one.

## 2. Get dependencies

From this project's root folder:

```
flutter pub get
```

## 3. Set up your Supabase project

1. Create a project at [supabase.com](https://supabase.com).
2. In the SQL Editor, run everything in `supabase/schema.sql` — same schema as
   the SwiftUI version, so if you already ran it for that project you can reuse
   the same Supabase project here.
3. In **Project Settings → API**, copy your Project URL and publishable/anon
   key into `lib/supabase_config.dart`.

## 4. Run it

```
flutter emulators          # see available simulators/emulators
flutter run                # builds and launches on the selected device
```

First launch: Welcome → Sign Up → Profile Setup → Explore.

To run on your physical iPhone: connect via cable, open `ios/Runner.xcworkspace`
once in Xcode to sign in with your Apple ID under Signing & Capabilities, trust
the developer certificate on the phone (Settings → General → VPN & Device
Management), then `flutter run` again with the phone selected.

## Notes on scope and follow-ups

- **Auth** is email/password only, same reasoning as the SwiftUI version —
  Apple/Google sign-in and phone OTP add real setup overhead better left for
  after the MVP.
- **Notifications**: the accept/reject flow updates `activity_participants`
  immediately; the dashboard picks that up on refresh/reopen rather than via
  push. Supabase Realtime can layer on top later without a schema change.
- **Location filtering** is a text match on `location` plus a category filter,
  not live GPS radius search yet — `latitude`/`longitude` columns are already
  in the schema for when you want that.
- Uses `provider` for the one piece of shared state that matters (auth
  session) and plain `StatefulWidget` + service calls everywhere else —
  no extra state-management layer, per the "don't overengineer" brief.
