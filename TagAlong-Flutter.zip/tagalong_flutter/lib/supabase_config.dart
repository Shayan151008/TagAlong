/// Fill these in from your Supabase project settings (Project Settings > API).
/// Use the "publishable" (or legacy "anon") key here — never the secret key.
class SupabaseConfig {
  static const String url = 'https://YOUR_PROJECT_REF.supabase.co';
  static const String anonKey = 'YOUR_SUPABASE_ANON_KEY';
}
