import 'package:flutter/material.dart';

/// Dark/violet design system — same palette as the SwiftUI build,
/// so both versions look identical.
class TAColor {
  static const background = Color(0xFF12101C);
  static const backgroundElevated = Color(0xFF1A1729);
  static const surface = Color(0xFF1E1B2E);
  static const surfaceHigh = Color(0xFF252140);

  static const primary = Color(0xFF7C6FF0);
  static const primaryDark = Color(0xFF5B4FD6);
  static const primaryTint = Color(0xFF2A2550);

  static const textPrimary = Colors.white;
  static const textSecondary = Color(0xFFB4AFC7);
  static const textMuted = Color(0xFF716C87);

  static const success = Color(0xFF4ADE80);
  static const successTint = Color(0xFF1B3327);
  static const warning = Color(0xFFF5B454);
  static const warningTint = Color(0xFF332A18);
  static const danger = Color(0xFFF87171);
  static const dangerTint = Color(0xFF3A1E1E);

  static const divider = Color(0xFF2B2740);

  static const primaryGradient = LinearGradient(
    colors: [primary, primaryDark],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );
}

class TASpacing {
  static const xs = 4.0;
  static const sm = 8.0;
  static const md = 12.0;
  static const lg = 16.0;
  static const xl = 24.0;
  static const xxl = 32.0;
}

class TARadius {
  static const sm = 12.0;
  static const md = 16.0;
  static const lg = 24.0;
  static const pill = 100.0;
}

ThemeData buildTagAlongTheme() {
  return ThemeData(
    useMaterial3: true,
    scaffoldBackgroundColor: TAColor.background,
    colorScheme: const ColorScheme.dark(
      primary: TAColor.primary,
      secondary: TAColor.primaryDark,
      surface: TAColor.surface,
      error: TAColor.danger,
    ),
    fontFamily: 'Roboto',
    textTheme: const TextTheme(
      headlineMedium: TextStyle(fontSize: 24, fontWeight: FontWeight.bold, color: TAColor.textPrimary),
      titleMedium: TextStyle(fontSize: 15.5, fontWeight: FontWeight.bold, color: TAColor.textPrimary),
      bodyMedium: TextStyle(fontSize: 14, color: TAColor.textSecondary),
      labelSmall: TextStyle(fontSize: 12, fontWeight: FontWeight.bold, color: TAColor.textMuted),
    ),
    tabBarTheme: const TabBarThemeData(
      labelColor: TAColor.textPrimary,
      unselectedLabelColor: TAColor.textMuted,
      indicatorColor: TAColor.primary,
    ),
    inputDecorationTheme: InputDecorationTheme(
      filled: true,
      fillColor: TAColor.surface,
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(TARadius.sm),
        borderSide: const BorderSide(color: TAColor.divider),
      ),
      contentPadding: const EdgeInsets.all(14),
    ),
  );
}
