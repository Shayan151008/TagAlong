import 'package:flutter/material.dart';
import '../app_theme.dart';
import '../models.dart';

class PrimaryButton extends StatelessWidget {
  final String title;
  final bool isLoading;
  final bool isDisabled;
  final VoidCallback onPressed;

  const PrimaryButton({
    super.key,
    required this.title,
    required this.onPressed,
    this.isLoading = false,
    this.isDisabled = false,
  });

  @override
  Widget build(BuildContext context) {
    return Opacity(
      opacity: isDisabled ? 0.5 : 1,
      child: Container(
        width: double.infinity,
        height: 52,
        decoration: BoxDecoration(
          gradient: TAColor.primaryGradient,
          borderRadius: BorderRadius.circular(TARadius.pill),
        ),
        child: Material(
          color: Colors.transparent,
          child: InkWell(
            borderRadius: BorderRadius.circular(TARadius.pill),
            onTap: (isDisabled || isLoading) ? null : onPressed,
            child: Center(
              child: isLoading
                  ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2))
                  : Text(title, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 15)),
            ),
          ),
        ),
      ),
    );
  }
}

class SecondaryButton extends StatelessWidget {
  final String title;
  final VoidCallback onPressed;
  const SecondaryButton({super.key, required this.title, required this.onPressed});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: double.infinity,
      height: 50,
      child: OutlinedButton(
        onPressed: onPressed,
        style: OutlinedButton.styleFrom(
          backgroundColor: TAColor.surface,
          side: const BorderSide(color: TAColor.divider),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(TARadius.pill)),
        ),
        child: Text(title, style: const TextStyle(color: TAColor.textPrimary, fontWeight: FontWeight.w600, fontSize: 14)),
      ),
    );
  }
}

class Pill extends StatelessWidget {
  final String text;
  final Color color;
  final Color tint;
  const Pill({super.key, required this.text, this.color = TAColor.primary, this.tint = TAColor.primaryTint});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
      decoration: BoxDecoration(color: tint, borderRadius: BorderRadius.circular(TARadius.pill)),
      child: Text(text, style: TextStyle(color: color, fontSize: 11, fontWeight: FontWeight.bold)),
    );
  }
}

Widget statusBadge(ParticipantStatus status) {
  switch (status) {
    case ParticipantStatus.pending:
      return const Pill(text: 'Pending approval', color: TAColor.warning, tint: TAColor.warningTint);
    case ParticipantStatus.accepted:
      return const Pill(text: 'Confirmed', color: TAColor.success, tint: TAColor.successTint);
    case ParticipantStatus.rejected:
      return const Pill(text: 'Not accepted', color: TAColor.danger, tint: TAColor.dangerTint);
  }
}

class AvatarView extends StatelessWidget {
  final String initials;
  final double size;
  const AvatarView({super.key, required this.initials, this.size = 34});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        gradient: TAColor.primaryGradient,
        shape: BoxShape.circle,
        border: Border.all(color: TAColor.background, width: 2),
      ),
      child: Center(
        child: Text(initials, style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: size * 0.38)),
      ),
    );
  }
}

class AvatarStack extends StatelessWidget {
  final List<String> initials;
  final double size;
  final int maxShown;
  const AvatarStack({super.key, required this.initials, this.size = 30, this.maxShown = 3});

  @override
  Widget build(BuildContext context) {
    final shown = initials.take(maxShown).toList();
    final overflow = initials.length - shown.length;
    return SizedBox(
      height: size,
      width: size + (shown.length - 1) * (size * 0.66) + (overflow > 0 ? size * 0.66 : 0),
      child: Stack(
        children: [
          for (int i = 0; i < shown.length; i++)
            Positioned(left: i * size * 0.66, child: AvatarView(initials: shown[i], size: size)),
          if (overflow > 0)
            Positioned(
              left: shown.length * size * 0.66,
              child: Container(
                width: size,
                height: size,
                decoration: BoxDecoration(color: TAColor.surfaceHigh, shape: BoxShape.circle, border: Border.all(color: TAColor.background, width: 2)),
                child: Center(child: Text('+$overflow', style: TextStyle(color: TAColor.textSecondary, fontSize: size * 0.34, fontWeight: FontWeight.bold))),
              ),
            ),
        ],
      ),
    );
  }
}

/// Trust ring — the signature element, used only around an organiser's
/// avatar on the activity detail screen so it reads as a real trust signal.
class TrustRingAvatar extends StatelessWidget {
  final String initials;
  final double size;
  const TrustRingAvatar({super.key, required this.initials, this.size = 52});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: size,
      height: size,
      padding: const EdgeInsets.all(2.5),
      decoration: const BoxDecoration(
        shape: BoxShape.circle,
        gradient: SweepGradient(colors: [TAColor.primary, TAColor.primaryDark, TAColor.primary]),
      ),
      child: AvatarView(initials: initials, size: size - 5),
    );
  }
}

class ActivityCardView extends StatelessWidget {
  final Activity activity;
  final List<String> goingInitials;
  final int goingCount;
  const ActivityCardView({super.key, required this.activity, this.goingInitials = const [], this.goingCount = 0});

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(color: TAColor.surface, borderRadius: BorderRadius.circular(TARadius.md)),
      clipBehavior: Clip.antiAlias,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            height: 110,
            width: double.infinity,
            decoration: const BoxDecoration(
              gradient: LinearGradient(colors: [TAColor.primaryTint, TAColor.surfaceHigh], begin: Alignment.topLeft, end: Alignment.bottomRight),
            ),
            padding: const EdgeInsets.all(10),
            child: Align(alignment: Alignment.topLeft, child: Pill(text: activity.category)),
          ),
          Padding(
            padding: const EdgeInsets.all(14),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(activity.title, maxLines: 2, overflow: TextOverflow.ellipsis,
                    style: const TextStyle(color: TAColor.textPrimary, fontWeight: FontWeight.bold, fontSize: 15.5)),
                const SizedBox(height: 6),
                Text(activity.scheduleSummary, style: const TextStyle(color: TAColor.textMuted, fontSize: 12.5)),
                const SizedBox(height: 10),
                Row(
                  children: [
                    AvatarStack(initials: goingInitials, size: 24, maxShown: 3),
                    const SizedBox(width: 6),
                    Text('$goingCount going', style: const TextStyle(color: TAColor.textSecondary, fontSize: 11.5, fontWeight: FontWeight.w600)),
                    const Spacer(),
                    Text(
                      activity.spotsRemaining > 0 ? '${activity.spotsRemaining} spots left' : 'Full · waitlist',
                      style: TextStyle(
                        color: activity.spotsRemaining > 0 ? TAColor.primary : TAColor.textMuted,
                        fontSize: 11.5,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class EmptyStateView extends StatelessWidget {
  final IconData icon;
  final String title;
  final String message;
  const EmptyStateView({super.key, required this.icon, required this.title, required this.message});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(top: 60),
      child: Column(
        children: [
          Container(
            width: 64, height: 64,
            decoration: const BoxDecoration(color: TAColor.surface, shape: BoxShape.circle),
            child: Icon(icon, color: TAColor.textMuted, size: 28),
          ),
          const SizedBox(height: 12),
          Text(title, style: const TextStyle(color: TAColor.textPrimary, fontSize: 14, fontWeight: FontWeight.w600)),
          const SizedBox(height: 6),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 40),
            child: Text(message, textAlign: TextAlign.center, style: const TextStyle(color: TAColor.textMuted, fontSize: 13)),
          ),
        ],
      ),
    );
  }
}

class TAField extends StatelessWidget {
  final String label;
  final String placeholder;
  final TextEditingController controller;
  final bool isSecure;
  const TAField({super.key, required this.label, required this.controller, this.placeholder = '', this.isSecure = false});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(label, style: const TextStyle(color: TAColor.textSecondary, fontSize: 12.5, fontWeight: FontWeight.w600)),
        const SizedBox(height: 6),
        TextField(
          controller: controller,
          obscureText: isSecure,
          style: const TextStyle(color: TAColor.textPrimary, fontSize: 14.5),
          decoration: InputDecoration(hintText: placeholder, hintStyle: const TextStyle(color: TAColor.textMuted)),
        ),
      ],
    );
  }
}
