import 'package:supabase_flutter/supabase_flutter.dart';
import '../models.dart';

class SafetyService {
  static final instance = SafetyService._();
  SafetyService._();
  SupabaseClient get _client => Supabase.instance.client;

  Future<void> report({
    required String reporterId,
    required String reportedUserId,
    String? activityId,
    required String reason,
  }) async {
    await _client.from('reports').insert({
      'reporter_id': reporterId,
      'reported_user_id': reportedUserId,
      'activity_id': activityId,
      'reason': reason,
    });
  }

  Future<void> block(String blockerId, String blockedId) async {
    await _client.from('blocks').insert({'blocker_id': blockerId, 'blocked_id': blockedId});
  }

  Future<void> unblock(String blockerId, String blockedId) async {
    await _client.from('blocks').delete().eq('blocker_id', blockerId).eq('blocked_id', blockedId);
  }

  Future<List<BlockedUser>> fetchBlockedUsers(String blockerId) async {
    final rows = await _client.from('blocked_users_with_profile').select().eq('blocker_id', blockerId);
    return (rows as List).map((r) => BlockedUser.fromJson(r)).toList();
  }
}
