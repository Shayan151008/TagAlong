import 'package:flutter/foundation.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class AuthService extends ChangeNotifier {
  AuthService._internal() {
    _client.auth.onAuthStateChange.listen((data) {
      session = data.session;
      notifyListeners();
    });
  }
  static final AuthService instance = AuthService._internal();

  SupabaseClient get _client => Supabase.instance.client;

  Session? session;
  bool isLoading = true;

  String? get currentUserId => session?.user.id;
  bool get isAuthenticated => session != null;

  Future<void> restoreSession() async {
    isLoading = true;
    notifyListeners();
    session = _client.auth.currentSession;
    isLoading = false;
    notifyListeners();
  }

  Future<void> signUp(String email, String password) async {
    final res = await _client.auth.signUp(email: email, password: password);
    session = res.session;
    notifyListeners();
  }

  Future<void> signIn(String email, String password) async {
    final res = await _client.auth.signInWithPassword(email: email, password: password);
    session = res.session;
    notifyListeners();
  }

  Future<void> signOut() async {
    await _client.auth.signOut();
    session = null;
    notifyListeners();
  }
}
