import 'package:supabase_flutter/supabase_flutter.dart';
import '../models.dart';

class ParticipantService {
  static final instance = ParticipantService._();
  ParticipantService._();
  SupabaseClient get _client => Supabase.instance.client;

  Future<void> requestToJoin(String activityId, String userId) async {
    await _client.from('activity_participants').insert({
      'activity_id': activityId,
      'user_id': userId,
      'status': 'pending',
    });
  }

  Future<ParticipantStatus?> myStatus(String activityId, String userId) async {
    final rows = await _client
        .from('activity_participants')
        .select()
        .eq('activity_id', activityId)
        .eq('user_id', userId);
    if ((rows as List).isEmpty) return null;
    return statusFromString(rows.first['status']);
  }

  Future<List<ActivityParticipant>> requestsForHost(String organiserId, {ParticipantStatus? status}) async {
    var query = _client.from('participants_with_requester').select().eq('organiser_id', organiserId);
    if (status != null) {
      query = query.eq('status', statusToString(status));
    }
    final rows = await query.order('requested_at', ascending: false);
    return (rows as List).map((r) => ActivityParticipant.fromJson(r)).toList();
  }

  Future<void> respond(String requestId, bool accept) async {
    await _client.from('activity_participants').update({
      'status': accept ? 'accepted' : 'rejected',
      'responded_at': DateTime.now().toIso8601String(),
    }).eq('id', requestId);
  }

  Future<List<ActivityParticipant>> myJoinedActivities(String userId) async {
    final rows = await _client
        .from('activity_participants')
        .select()
        .eq('user_id', userId)
        .order('requested_at', ascending: false);
    return (rows as List).map((r) => ActivityParticipant.fromJson(r)).toList();
  }
}
