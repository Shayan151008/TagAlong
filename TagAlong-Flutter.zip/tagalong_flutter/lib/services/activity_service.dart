import 'package:supabase_flutter/supabase_flutter.dart';
import '../models.dart';

class NewActivityInput {
  String title = '';
  String category = activityCategories[1]; // Outdoors
  DateTime date = DateTime.now();
  String time = '18:00';
  String location = '';
  int maxParticipants = 8;
  String description = '';

  bool get isValid => title.trim().isNotEmpty && location.trim().isNotEmpty && maxParticipants > 1;
}

class ActivityService {
  static final instance = ActivityService._();
  ActivityService._();
  SupabaseClient get _client => Supabase.instance.client;

  Future<List<Activity>> fetchNearby({String? category, String? neighbourhood}) async {
    var query = _client.from('activities_with_counts').select();
    if (category != null && category != 'All') {
      query = query.eq('category', category);
    }
    if (neighbourhood != null && neighbourhood.isNotEmpty) {
      query = query.ilike('location', '%$neighbourhood%');
    }
    final rows = await query.order('date', ascending: true);
    return (rows as List).map((r) => Activity.fromJson(r)).toList();
  }

  Future<Activity> fetchActivity(String id) async {
    final row = await _client.from('activities_with_counts').select().eq('id', id).single();
    return Activity.fromJson(row);
  }

  Future<List<Profile>> fetchGoing(String activityId) async {
    final rows = await _client.from('accepted_participants_with_profile').select().eq('activity_id', activityId);
    return (rows as List).map((r) => Profile.fromJson(r)).toList();
  }

  Future<void> createActivity(NewActivityInput input, String organiserId) async {
    await _client.from('activities').insert({
      'organiser_id': organiserId,
      'title': input.title,
      'description': input.description,
      'category': input.category,
      'date': '${input.date.year.toString().padLeft(4, '0')}-${input.date.month.toString().padLeft(2, '0')}-${input.date.day.toString().padLeft(2, '0')}',
      'time': input.time,
      'location': input.location,
      'max_participants': input.maxParticipants,
    });
  }

  Future<List<Activity>> fetchHosted(String organiserId) async {
    final rows = await _client
        .from('activities_with_counts')
        .select()
        .eq('organiser_id', organiserId)
        .order('date', ascending: true);
    return (rows as List).map((r) => Activity.fromJson(r)).toList();
  }
}
