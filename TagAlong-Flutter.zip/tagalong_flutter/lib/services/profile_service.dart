import 'package:supabase_flutter/supabase_flutter.dart';
import '../models.dart';

class ProfileService {
  static final instance = ProfileService._();
  ProfileService._();
  SupabaseClient get _client => Supabase.instance.client;

  Future<Profile?> fetchProfile(String id) async {
    final row = await _client.from('profiles').select().eq('id', id).maybeSingle();
    if (row == null) return null;
    return Profile.fromJson(row);
  }

  Future<void> upsertProfile(Profile profile) async {
    await _client.from('profiles').upsert(profile.toJson());
  }

  Future<(int hosted, int joined)> fetchStats(String userId) async {
    final hosted = await _client.from('activities').select('id').eq('organiser_id', userId);
    final joined = await _client
        .from('activity_participants')
        .select('id')
        .eq('user_id', userId)
        .eq('status', 'accepted');
    return ((hosted as List).length, (joined as List).length);
  }
}
