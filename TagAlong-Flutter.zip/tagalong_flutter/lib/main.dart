import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import 'app_theme.dart';
import 'supabase_config.dart';
import 'services/auth_service.dart';
import 'screens/root_view.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Supabase.initialize(url: SupabaseConfig.url, anonKey: SupabaseConfig.anonKey);
  await AuthService.instance.restoreSession();
  runApp(const TagAlongApp());
}

class TagAlongApp extends StatelessWidget {
  const TagAlongApp({super.key});

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider.value(
      value: AuthService.instance,
      child: MaterialApp(
        title: 'TagAlong',
        debugShowCheckedModeBanner: false,
        theme: buildTagAlongTheme(),
        darkTheme: buildTagAlongTheme(),
        themeMode: ThemeMode.dark,
        home: const RootView(),
      ),
    );
  }
}
