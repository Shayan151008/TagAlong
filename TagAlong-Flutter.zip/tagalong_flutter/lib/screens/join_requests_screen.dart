import 'package:flutter/material.dart';
import '../app_theme.dart';
import '../models.dart';
import '../services/auth_service.dart';
import '../services/participant_service.dart';
import '../widgets/components.dart';

class JoinRequestsScreen extends StatefulWidget {
  const JoinRequestsScreen({super.key});
  @override
  State<JoinRequestsScreen> createState() => _JoinRequestsScreenState();
}

class _JoinRequestsScreenState extends State<JoinRequestsScreen> with SingleTickerProviderStateMixin {
  List<ActivityParticipant> _pending = [];
  List<ActivityParticipant> _accepted = [];
  String? _respondingId;
  late TabController _tabController;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
    _load();
  }

  Future<void> _load() async {
    final uid = AuthService.instance.currentUserId;
    if (uid == null) return;
    final pending = await ParticipantService.instance.requestsForHost(uid, status: ParticipantStatus.pending);
    final accepted = await ParticipantService.instance.requestsForHost(uid, status: ParticipantStatus.accepted);
    if (!mounted) return;
    setState(() { _pending = pending; _accepted = accepted; });
  }

  Future<void> _respond(ActivityParticipant request, bool accept) async {
    setState(() => _respondingId = request.id);
    await ParticipantService.instance.respond(request.id, accept);
    await _load();
    if (mounted) setState(() => _respondingId = null);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: TAColor.background,
      appBar: AppBar(
        backgroundColor: TAColor.background,
        title: const Text('Join Requests', style: TextStyle(color: TAColor.textPrimary)),
        bottom: TabBar(controller: _tabController, tabs: const [Tab(text: 'Pending'), Tab(text: 'Approved')]),
      ),
      body: TabBarView(
        controller: _tabController,
        children: [
          _list(_pending, 'tray', 'No pending requests', 'New requests to join your activities will show up here.'),
          _list(_accepted, 'check', 'No approved members yet', 'Approve a request to see it here.'),
        ],
      ),
    );
  }

  Widget _list(List<ActivityParticipant> items, String iconKey, String emptyTitle, String emptyMessage) {
    if (items.isEmpty) {
      return EmptyStateView(icon: iconKey == 'tray' ? Icons.inbox_outlined : Icons.check_circle_outline, title: emptyTitle, message: emptyMessage);
    }
    return ListView.separated(
      padding: const EdgeInsets.all(TASpacing.lg),
      itemCount: items.length,
      separatorBuilder: (_, __) => const SizedBox(height: TASpacing.md),
      itemBuilder: (context, i) => _requestRow(items[i]),
    );
  }

  Widget _requestRow(ActivityParticipant request) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(color: TAColor.surface, borderRadius: BorderRadius.circular(TARadius.md)),
      child: Row(
        children: [
          AvatarView(initials: request.requesterInitials ?? '?', size: 40),
          const SizedBox(width: TASpacing.md),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(request.requesterName ?? 'Someone', style: const TextStyle(color: TAColor.textPrimary, fontSize: 13.5, fontWeight: FontWeight.bold)),
                const Text('Requested to join', style: TextStyle(color: TAColor.textMuted, fontSize: 12)),
              ],
            ),
          ),
          if (request.status == ParticipantStatus.pending)
            _respondingId == request.id
                ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(color: TAColor.primary, strokeWidth: 2))
                : Row(
                    children: [
                      _iconAction(Icons.close, TAColor.danger, TAColor.dangerTint, () => _respond(request, false)),
                      const SizedBox(width: 8),
                      _iconAction(Icons.check, TAColor.success, TAColor.successTint, () => _respond(request, true)),
                    ],
                  )
          else
            statusBadge(request.status),
        ],
      ),
    );
  }

  Widget _iconAction(IconData icon, Color color, Color bg, VoidCallback onTap) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.all(8),
        decoration: BoxDecoration(color: bg, shape: BoxShape.circle),
        child: Icon(icon, size: 16, color: color),
      ),
    );
  }
}
