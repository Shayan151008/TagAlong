import 'package:flutter/material.dart';
import '../app_theme.dart';
import '../models.dart';
import '../services/auth_service.dart';
import '../services/profile_service.dart';
import '../widgets/components.dart';

class ProfileSetupScreen extends StatefulWidget {
  final ValueChanged<Profile> onComplete;
  const ProfileSetupScreen({super.key, required this.onComplete});

  @override
  State<ProfileSetupScreen> createState() => _ProfileSetupScreenState();
}

class _ProfileSetupScreenState extends State<ProfileSetupScreen> {
  final _name = TextEditingController();
  final _bio = TextEditingController();
  final _location = TextEditingController();
  bool _isLoading = false;
  String? _error;

  Future<void> _save() async {
    final uid = AuthService.instance.currentUserId;
    if (uid == null) return;
    setState(() { _isLoading = true; _error = null; });
    final profile = Profile(
      id: uid,
      fullName: _name.text.trim(),
      bio: _bio.text.trim().isEmpty ? null : _bio.text.trim(),
      location: _location.text.trim().isEmpty ? null : _location.text.trim(),
      interests: [],
    );
    try {
      await ProfileService.instance.upsertProfile(profile);
      widget.onComplete(profile);
    } catch (e) {
      setState(() => _error = "Couldn't save your profile. Please try again.");
    }
    if (mounted) setState(() => _isLoading = false);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: TAColor.background,
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(TASpacing.xl),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('Almost there', style: Theme.of(context).textTheme.headlineMedium),
              const SizedBox(height: 4),
              const Text("Let's set up your profile", style: TextStyle(color: TAColor.textSecondary, fontSize: 14)),
              const SizedBox(height: TASpacing.lg),
              Center(
                child: Container(
                  width: 88, height: 88,
                  decoration: const BoxDecoration(color: TAColor.surface, shape: BoxShape.circle),
                  child: const Icon(Icons.camera_alt_outlined, color: TAColor.textMuted),
                ),
              ),
              const SizedBox(height: TASpacing.lg),
              TAField(label: 'Full name', placeholder: 'Your name', controller: _name),
              const SizedBox(height: TASpacing.lg),
              TAField(label: 'Bio', placeholder: 'Love sports, coffee and meeting new people', controller: _bio),
              const SizedBox(height: TASpacing.lg),
              TAField(label: 'Location', placeholder: 'Bengaluru, India', controller: _location),
              if (_error != null) ...[
                const SizedBox(height: TASpacing.sm),
                Text(_error!, style: const TextStyle(color: TAColor.danger, fontSize: 12)),
              ],
              const SizedBox(height: TASpacing.lg),
              PrimaryButton(
                title: 'Continue',
                isLoading: _isLoading,
                isDisabled: _name.text.trim().isEmpty,
                onPressed: _save,
              ),
            ],
          ),
        ),
      ),
    );
  }
}
