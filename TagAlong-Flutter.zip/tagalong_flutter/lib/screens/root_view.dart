import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../app_theme.dart';
import '../models.dart';
import '../services/auth_service.dart';
import '../services/profile_service.dart';
import 'welcome_screen.dart';
import 'profile_setup_screen.dart';
import 'home_feed_screen.dart';
import 'create_activity_screen.dart';
import 'my_activities_screen.dart';
import 'profile_screen.dart';

class RootView extends StatefulWidget {
  const RootView({super.key});
  @override
  State<RootView> createState() => _RootViewState();
}

class _RootViewState extends State<RootView> {
  Profile? _profile;
  bool _checkingProfile = false;
  String? _lastCheckedUserId;

  Future<void> _checkProfile(String userId) async {
    if (_lastCheckedUserId == userId) return;
    _lastCheckedUserId = userId;
    setState(() => _checkingProfile = true);
    final profile = await ProfileService.instance.fetchProfile(userId);
    if (!mounted) return;
    setState(() {
      _profile = profile;
      _checkingProfile = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthService>();

    if (auth.isLoading) return const SplashScreen();
    if (!auth.isAuthenticated) return const WelcomeScreen();

    final uid = auth.currentUserId!;
    if (_lastCheckedUserId != uid) {
      WidgetsBinding.instance.addPostFrameCallback((_) => _checkProfile(uid));
      return const SplashScreen();
    }
    if (_checkingProfile) return const SplashScreen();
    if (_profile == null) {
      return ProfileSetupScreen(onComplete: (p) => setState(() => _profile = p));
    }
    return MainTabView(profile: _profile!, onProfileChanged: (p) => setState(() => _profile = p));
  }
}

class SplashScreen extends StatelessWidget {
  const SplashScreen({super.key});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: TAColor.background,
      body: Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 64, height: 64,
              decoration: BoxDecoration(gradient: TAColor.primaryGradient, borderRadius: BorderRadius.circular(20)),
              child: const Icon(Icons.people_alt_rounded, color: Colors.white, size: 28),
            ),
            const SizedBox(height: 12),
            const Text('TagAlong', style: TextStyle(color: Colors.white, fontSize: 24, fontWeight: FontWeight.bold)),
          ],
        ),
      ),
    );
  }
}

class MainTabView extends StatefulWidget {
  final Profile profile;
  final ValueChanged<Profile> onProfileChanged;
  const MainTabView({super.key, required this.profile, required this.onProfileChanged});

  @override
  State<MainTabView> createState() => _MainTabViewState();
}

class _MainTabViewState extends State<MainTabView> {
  int _index = 0;

  @override
  Widget build(BuildContext context) {
    final pages = [
      const HomeFeedScreen(),
      const CreateActivityScreen(),
      const MyActivitiesScreen(),
      ProfileScreen(profile: widget.profile, onProfileChanged: widget.onProfileChanged),
    ];

    return Scaffold(
      backgroundColor: TAColor.background,
      body: pages[_index],
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _index,
        onTap: (i) => setState(() => _index = i),
        type: BottomNavigationBarType.fixed,
        backgroundColor: TAColor.surface,
        selectedItemColor: TAColor.primary,
        unselectedItemColor: TAColor.textMuted,
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.explore_outlined), label: 'Explore'),
          BottomNavigationBarItem(icon: Icon(Icons.add_circle), label: 'Host'),
          BottomNavigationBarItem(icon: Icon(Icons.calendar_today_outlined), label: 'My Activities'),
          BottomNavigationBarItem(icon: Icon(Icons.person_outline), label: 'Profile'),
        ],
      ),
    );
  }
}
