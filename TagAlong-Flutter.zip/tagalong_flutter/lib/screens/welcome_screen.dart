import 'package:flutter/material.dart';
import '../app_theme.dart';
import '../services/auth_service.dart';
import '../widgets/components.dart';

class WelcomeScreen extends StatelessWidget {
  const WelcomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: TAColor.background,
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(TASpacing.xl),
          child: Column(
            children: [
              const Spacer(),
              Container(
                height: 200,
                decoration: BoxDecoration(
                  gradient: const LinearGradient(colors: [TAColor.primaryTint, TAColor.surfaceHigh], begin: Alignment.topCenter, end: Alignment.bottomCenter),
                  borderRadius: BorderRadius.circular(TARadius.lg),
                ),
                child: const Center(child: Icon(Icons.people_alt_rounded, size: 46, color: TAColor.primary)),
              ),
              const SizedBox(height: TASpacing.lg),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('Say yes to the plan\nyou\'d usually skip.',
                      style: Theme.of(context).textTheme.headlineMedium),
                  const SizedBox(height: TASpacing.sm),
                  const Text(
                    'See who\'s hosting, who\'s going, and why — before you ever show up.',
                    style: TextStyle(color: TAColor.textSecondary, fontSize: 14),
                  ),
                ],
              ),
              const Spacer(),
              PrimaryButton(title: 'Get started', onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const SignUpScreen()))),
              const SizedBox(height: TASpacing.sm),
              SecondaryButton(title: 'I already have an account', onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const LoginScreen()))),
            ],
          ),
        ),
      ),
    );
  }
}

class SignUpScreen extends StatefulWidget {
  const SignUpScreen({super.key});
  @override
  State<SignUpScreen> createState() => _SignUpScreenState();
}

class _SignUpScreenState extends State<SignUpScreen> {
  final _email = TextEditingController();
  final _password = TextEditingController();
  bool _isLoading = false;
  String? _error;

  Future<void> _submit() async {
    setState(() { _isLoading = true; _error = null; });
    try {
      await AuthService.instance.signUp(_email.text.trim(), _password.text);
    } catch (e) {
      setState(() => _error = 'Something went wrong. Check your details and try again.');
    }
    if (mounted) setState(() => _isLoading = false);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: TAColor.background,
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(TASpacing.xl),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('Create your account', style: Theme.of(context).textTheme.headlineMedium),
              const SizedBox(height: TASpacing.lg),
              TAField(label: 'Email', placeholder: 'you@example.com', controller: _email),
              const SizedBox(height: TASpacing.lg),
              TAField(label: 'Password', placeholder: 'At least 8 characters', controller: _password, isSecure: true),
              if (_error != null) ...[
                const SizedBox(height: TASpacing.sm),
                Text(_error!, style: const TextStyle(color: TAColor.danger, fontSize: 12)),
              ],
              const SizedBox(height: TASpacing.lg),
              PrimaryButton(title: 'Continue', isLoading: _isLoading, onPressed: _submit),
            ],
          ),
        ),
      ),
    );
  }
}

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});
  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _email = TextEditingController();
  final _password = TextEditingController();
  bool _isLoading = false;
  String? _error;

  Future<void> _submit() async {
    setState(() { _isLoading = true; _error = null; });
    try {
      await AuthService.instance.signIn(_email.text.trim(), _password.text);
    } catch (e) {
      setState(() => _error = 'Something went wrong. Check your details and try again.');
    }
    if (mounted) setState(() => _isLoading = false);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: TAColor.background,
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(TASpacing.xl),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('Welcome back', style: Theme.of(context).textTheme.headlineMedium),
              const SizedBox(height: TASpacing.lg),
              TAField(label: 'Email', placeholder: 'you@example.com', controller: _email),
              const SizedBox(height: TASpacing.lg),
              TAField(label: 'Password', placeholder: 'Your password', controller: _password, isSecure: true),
              if (_error != null) ...[
                const SizedBox(height: TASpacing.sm),
                Text(_error!, style: const TextStyle(color: TAColor.danger, fontSize: 12)),
              ],
              const SizedBox(height: TASpacing.lg),
              PrimaryButton(title: 'Log in', isLoading: _isLoading, onPressed: _submit),
            ],
          ),
        ),
      ),
    );
  }
}
