import 'package:flutter/material.dart';
import '../app_theme.dart';
import '../models.dart';
import '../services/activity_service.dart';
import '../widgets/components.dart';
import 'activity_detail_screen.dart';

class HomeFeedScreen extends StatefulWidget {
  const HomeFeedScreen({super.key});
  @override
  State<HomeFeedScreen> createState() => _HomeFeedScreenState();
}

class _HomeFeedScreenState extends State<HomeFeedScreen> {
  List<Activity> _activities = [];
  String _selectedCategory = 'All';
  bool _isLoading = false;
  final _searchController = TextEditingController();

  final _categories = ['All', ...activityCategories];

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() => _isLoading = true);
    try {
      final results = await ActivityService.instance.fetchNearby(category: _selectedCategory);
      setState(() => _activities = results);
    } catch (_) {
      // Keep list empty; card below shows the empty state.
    }
    setState(() => _isLoading = false);
  }

  List<Activity> get _filtered {
    final q = _searchController.text.trim().toLowerCase();
    if (q.isEmpty) return _activities;
    return _activities.where((a) => a.title.toLowerCase().contains(q)).toList();
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: RefreshIndicator(
        onRefresh: _load,
        color: TAColor.primary,
        backgroundColor: TAColor.surface,
        child: ListView(
          padding: const EdgeInsets.all(TASpacing.lg),
          children: [
            const Text('Explore', style: TextStyle(color: TAColor.textPrimary, fontSize: 24, fontWeight: FontWeight.bold)),
            const SizedBox(height: TASpacing.lg),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 4),
              decoration: BoxDecoration(color: TAColor.surface, borderRadius: BorderRadius.circular(TARadius.pill)),
              child: TextField(
                controller: _searchController,
                onChanged: (_) => setState(() {}),
                style: const TextStyle(color: TAColor.textPrimary),
                decoration: const InputDecoration(
                  isDense: true,
                  border: InputBorder.none,
                  filled: false,
                  icon: Icon(Icons.search, color: TAColor.textMuted),
                  hintText: 'Search activities near you',
                  hintStyle: TextStyle(color: TAColor.textMuted, fontSize: 13),
                ),
              ),
            ),
            const SizedBox(height: TASpacing.md),
            SizedBox(
              height: 40,
              child: ListView.separated(
                scrollDirection: Axis.horizontal,
                itemCount: _categories.length,
                separatorBuilder: (_, __) => const SizedBox(width: TASpacing.sm),
                itemBuilder: (context, i) {
                  final cat = _categories[i];
                  final active = cat == _selectedCategory;
                  return GestureDetector(
                    onTap: () { setState(() => _selectedCategory = cat); _load(); },
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 9),
                      decoration: BoxDecoration(
                        gradient: active ? TAColor.primaryGradient : null,
                        color: active ? null : TAColor.surface,
                        borderRadius: BorderRadius.circular(TARadius.pill),
                      ),
                      child: Center(child: Text(cat, style: TextStyle(color: active ? Colors.white : TAColor.textSecondary, fontSize: 12.5, fontWeight: FontWeight.w600))),
                    ),
                  );
                },
              ),
            ),
            const SizedBox(height: TASpacing.lg),
            if (_isLoading)
              const Padding(padding: EdgeInsets.only(top: 40), child: Center(child: CircularProgressIndicator(color: TAColor.primary)))
            else if (_filtered.isEmpty)
              const EmptyStateView(icon: Icons.directions_walk, title: 'Nothing nearby yet', message: 'Try a different category, or be the first to host something here.')
            else
              ..._filtered.map((activity) => Padding(
                    padding: const EdgeInsets.only(bottom: TASpacing.md),
                    child: GestureDetector(
                      onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ActivityDetailScreen(activityId: activity.id))),
                      child: ActivityCardView(activity: activity, goingInitials: const ['R', 'S', 'A'], goingCount: activity.acceptedCount),
                    ),
                  )),
          ],
        ),
      ),
    );
  }
}
