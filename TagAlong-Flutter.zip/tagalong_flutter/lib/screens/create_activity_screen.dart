import 'package:flutter/material.dart';
import '../app_theme.dart';
import '../models.dart';
import '../services/activity_service.dart';
import '../services/auth_service.dart';
import '../widgets/components.dart';

class CreateActivityScreen extends StatefulWidget {
  const CreateActivityScreen({super.key});
  @override
  State<CreateActivityScreen> createState() => _CreateActivityScreenState();
}

class _CreateActivityScreenState extends State<CreateActivityScreen> {
  final _input = NewActivityInput();
  final _titleController = TextEditingController();
  final _locationController = TextEditingController();
  final _descriptionController = TextEditingController();
  bool _isSubmitting = false;
  String? _error;

  Future<void> _pickDate() async {
    final picked = await showDatePicker(
      context: context, initialDate: _input.date,
      firstDate: DateTime.now(), lastDate: DateTime.now().add(const Duration(days: 365)),
    );
    if (picked != null) setState(() => _input.date = picked);
  }

  Future<void> _pickTime() async {
    final picked = await showTimePicker(context: context, initialTime: TimeOfDay.now());
    if (picked != null) {
      setState(() => _input.time = '${picked.hour.toString().padLeft(2, '0')}:${picked.minute.toString().padLeft(2, '0')}');
    }
  }

  Future<void> _publish() async {
    _input.title = _titleController.text;
    _input.location = _locationController.text;
    _input.description = _descriptionController.text;

    if (!_input.isValid) {
      setState(() => _error = 'Fill in a title, location, and a group size above 1.');
      return;
    }
    final uid = AuthService.instance.currentUserId;
    if (uid == null) return;

    setState(() { _isSubmitting = true; _error = null; });
    try {
      await ActivityService.instance.createActivity(_input, uid);
      _titleController.clear(); _locationController.clear(); _descriptionController.clear();
      if (mounted) {
        showDialog(context: context, builder: (_) => AlertDialog(
          backgroundColor: TAColor.surface,
          title: const Text('Activity published', style: TextStyle(color: TAColor.textPrimary)),
          content: const Text("Your activity is live. You'll see join requests under My Activities.", style: TextStyle(color: TAColor.textSecondary)),
          actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('OK'))],
        ));
      }
    } catch (_) {
      setState(() => _error = "Couldn't publish this activity. Please try again.");
    }
    setState(() => _isSubmitting = false);
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: SingleChildScrollView(
        padding: const EdgeInsets.all(TASpacing.lg),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('Host an activity', style: TextStyle(color: TAColor.textPrimary, fontSize: 22, fontWeight: FontWeight.bold)),
            const SizedBox(height: TASpacing.lg),
            TAField(label: 'Title', placeholder: 'Sunset badminton + chai', controller: _titleController),
            const SizedBox(height: TASpacing.lg),

            const Text('Category', style: TextStyle(color: TAColor.textSecondary, fontSize: 12.5, fontWeight: FontWeight.w600)),
            const SizedBox(height: 6),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 14),
              decoration: BoxDecoration(color: TAColor.surface, borderRadius: BorderRadius.circular(TARadius.sm)),
              child: DropdownButtonHideUnderline(
                child: DropdownButton<String>(
                  value: _input.category,
                  isExpanded: true,
                  dropdownColor: TAColor.surface,
                  style: const TextStyle(color: TAColor.textPrimary),
                  items: activityCategories.map((c) => DropdownMenuItem(value: c, child: Text(c))).toList(),
                  onChanged: (v) => setState(() => _input.category = v ?? _input.category),
                ),
              ),
            ),
            const SizedBox(height: TASpacing.lg),

            Row(
              children: [
                Expanded(child: _pickerField('Date', '${_input.date.toLocal()}'.split(' ')[0], _pickDate)),
                const SizedBox(width: TASpacing.md),
                Expanded(child: _pickerField('Time', _input.time, _pickTime)),
              ],
            ),
            const SizedBox(height: TASpacing.lg),

            TAField(label: 'Location', placeholder: 'Koramangala 5th Block', controller: _locationController),
            const SizedBox(height: TASpacing.lg),

            Container(
              padding: const EdgeInsets.symmetric(horizontal: 14),
              decoration: BoxDecoration(color: TAColor.surface, borderRadius: BorderRadius.circular(TARadius.sm)),
              child: Row(
                children: [
                  Text('Max participants: ${_input.maxParticipants}', style: const TextStyle(color: TAColor.textPrimary, fontSize: 13.5, fontWeight: FontWeight.w600)),
                  const Spacer(),
                  IconButton(icon: const Icon(Icons.remove, color: TAColor.textSecondary), onPressed: () => setState(() { if (_input.maxParticipants > 2) _input.maxParticipants--; })),
                  IconButton(icon: const Icon(Icons.add, color: TAColor.textSecondary), onPressed: () => setState(() { if (_input.maxParticipants < 50) _input.maxParticipants++; })),
                ],
              ),
            ),
            const SizedBox(height: TASpacing.lg),

            const Text('Description', style: TextStyle(color: TAColor.textSecondary, fontSize: 12.5, fontWeight: FontWeight.w600)),
            const SizedBox(height: 6),
            Container(
              decoration: BoxDecoration(color: TAColor.surface, borderRadius: BorderRadius.circular(TARadius.sm)),
              child: TextField(
                controller: _descriptionController,
                maxLines: 4,
                style: const TextStyle(color: TAColor.textPrimary),
                decoration: const InputDecoration(border: InputBorder.none, contentPadding: EdgeInsets.all(12)),
              ),
            ),
            if (_error != null) ...[
              const SizedBox(height: TASpacing.sm),
              Text(_error!, style: const TextStyle(color: TAColor.danger, fontSize: 12)),
            ],
            const SizedBox(height: TASpacing.lg),
            PrimaryButton(title: 'Publish activity', isLoading: _isSubmitting, onPressed: _publish),
          ],
        ),
      ),
    );
  }

  Widget _pickerField(String label, String value, VoidCallback onTap) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(label, style: const TextStyle(color: TAColor.textSecondary, fontSize: 12.5, fontWeight: FontWeight.w600)),
        const SizedBox(height: 6),
        GestureDetector(
          onTap: onTap,
          child: Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(color: TAColor.surface, borderRadius: BorderRadius.circular(TARadius.sm)),
            child: Text(value, style: const TextStyle(color: TAColor.textPrimary, fontSize: 14)),
          ),
        ),
      ],
    );
  }
}
