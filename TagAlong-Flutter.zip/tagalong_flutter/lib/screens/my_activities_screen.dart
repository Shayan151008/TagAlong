import 'package:flutter/material.dart';
import '../app_theme.dart';
import '../models.dart';
import '../services/activity_service.dart';
import '../services/auth_service.dart';
import '../services/participant_service.dart';
import '../widgets/components.dart';
import 'activity_detail_screen.dart';
import 'join_requests_screen.dart';

class MyActivitiesScreen extends StatefulWidget {
  const MyActivitiesScreen({super.key});
  @override
  State<MyActivitiesScreen> createState() => _MyActivitiesScreenState();
}

class _MyActivitiesScreenState extends State<MyActivitiesScreen> with SingleTickerProviderStateMixin {
  late TabController _tabController;
  List<Activity> _hosted = [];
  List<MyActivityRow> _joined = [];
  List<MyActivityRow> _pending = [];

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 3, vsync: this);
    _load();
  }

  Future<void> _load() async {
    final uid = AuthService.instance.currentUserId;
    if (uid == null) return;

    final hosted = await ActivityService.instance.fetchHosted(uid);
    final requests = await ParticipantService.instance.myJoinedActivities(uid);

    final joined = <MyActivityRow>[];
    final pending = <MyActivityRow>[];
    for (final request in requests) {
      try {
        final activity = await ActivityService.instance.fetchActivity(request.activityId);
        final row = MyActivityRow(activity: activity, myStatus: request.status);
        if (request.status == ParticipantStatus.accepted) joined.add(row);
        if (request.status == ParticipantStatus.pending) pending.add(row);
      } catch (_) {}
    }

    if (!mounted) return;
    setState(() { _hosted = hosted; _joined = joined; _pending = pending; });
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(TASpacing.lg, TASpacing.lg, TASpacing.lg, 0),
            child: Row(children: [
              const Text('My Activities', style: TextStyle(color: TAColor.textPrimary, fontSize: 22, fontWeight: FontWeight.bold)),
            ]),
          ),
          TabBar(controller: _tabController, tabs: const [Tab(text: 'Hosting'), Tab(text: 'Joined'), Tab(text: 'Pending')]),
          Expanded(
            child: TabBarView(
              controller: _tabController,
              children: [_hostedTab(), _rowsTab(_joined, Icons.check_circle_outline, 'No confirmed plans yet', "Activities you're accepted into will show up here."),
                _rowsTab(_pending, Icons.hourglass_empty, 'Nothing pending', 'Requests you send will show up here while you wait to hear back.')],
            ),
          ),
        ],
      ),
    );
  }

  Widget _hostedTab() {
    if (_hosted.isEmpty) {
      return const EmptyStateView(icon: Icons.campaign_outlined, title: "You're not hosting anything yet", message: 'Create an activity and people nearby will be able to request to join.');
    }
    return RefreshIndicator(
      onRefresh: _load,
      color: TAColor.primary,
      child: ListView.separated(
        padding: const EdgeInsets.all(TASpacing.lg),
        itemCount: _hosted.length,
        separatorBuilder: (_, __) => const SizedBox(height: TASpacing.md),
        itemBuilder: (context, i) {
          final activity = _hosted[i];
          return GestureDetector(
            onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const JoinRequestsScreen())),
            child: _dashCard(activity, Text('${activity.acceptedCount}/${activity.maxParticipants} joined', style: const TextStyle(color: TAColor.textMuted, fontSize: 11))),
          );
        },
      ),
    );
  }

  Widget _rowsTab(List<MyActivityRow> rows, IconData icon, String title, String message) {
    if (rows.isEmpty) {
      return EmptyStateView(icon: icon, title: title, message: message);
    }
    return RefreshIndicator(
      onRefresh: _load,
      color: TAColor.primary,
      child: ListView.separated(
        padding: const EdgeInsets.all(TASpacing.lg),
        itemCount: rows.length,
        separatorBuilder: (_, __) => const SizedBox(height: TASpacing.md),
        itemBuilder: (context, i) {
          final row = rows[i];
          return GestureDetector(
            onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ActivityDetailScreen(activityId: row.activity.id))),
            child: _dashCard(row.activity, row.myStatus != null ? statusBadge(row.myStatus!) : const SizedBox.shrink()),
          );
        },
      ),
    );
  }

  Widget _dashCard(Activity activity, Widget trailing) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(color: TAColor.surface, borderRadius: BorderRadius.circular(TARadius.md)),
      child: Row(
        children: [
          Container(
            width: 52, height: 52,
            decoration: BoxDecoration(
              gradient: const LinearGradient(colors: [TAColor.primaryTint, TAColor.surfaceHigh], begin: Alignment.topLeft, end: Alignment.bottomRight),
              borderRadius: BorderRadius.circular(12),
            ),
          ),
          const SizedBox(width: TASpacing.md),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(activity.title, style: const TextStyle(color: TAColor.textPrimary, fontSize: 13.5, fontWeight: FontWeight.bold)),
                const SizedBox(height: 3),
                Text(activity.scheduleSummary, style: const TextStyle(color: TAColor.textMuted, fontSize: 11.5)),
                const SizedBox(height: 6),
                trailing,
              ],
            ),
          ),
        ],
      ),
    );
  }
}
