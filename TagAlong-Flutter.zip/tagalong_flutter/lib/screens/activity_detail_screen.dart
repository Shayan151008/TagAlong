import 'package:flutter/material.dart';
import '../app_theme.dart';
import '../models.dart';
import '../services/activity_service.dart';
import '../services/auth_service.dart';
import '../services/participant_service.dart';
import '../services/profile_service.dart';
import '../services/safety_service.dart';
import '../widgets/components.dart';

class ActivityDetailScreen extends StatefulWidget {
  final String activityId;
  const ActivityDetailScreen({super.key, required this.activityId});

  @override
  State<ActivityDetailScreen> createState() => _ActivityDetailScreenState();
}

class _ActivityDetailScreenState extends State<ActivityDetailScreen> {
  Activity? _activity;
  Profile? _organiser;
  List<Profile> _going = [];
  ParticipantStatus? _myStatus;
  bool _isLoading = true;
  bool _isSubmitting = false;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() => _isLoading = true);
    try {
      final activity = await ActivityService.instance.fetchActivity(widget.activityId);
      final organiser = await ProfileService.instance.fetchProfile(activity.organiserId);
      final going = await ActivityService.instance.fetchGoing(widget.activityId);
      final uid = AuthService.instance.currentUserId;
      final myStatus = uid != null ? await ParticipantService.instance.myStatus(widget.activityId, uid) : null;
      setState(() {
        _activity = activity;
        _organiser = organiser;
        _going = going;
        _myStatus = myStatus;
      });
    } catch (_) {}
    setState(() => _isLoading = false);
  }

  Future<void> _requestToJoin() async {
    final uid = AuthService.instance.currentUserId;
    if (uid == null) return;
    setState(() => _isSubmitting = true);
    try {
      await ParticipantService.instance.requestToJoin(widget.activityId, uid);
      setState(() => _myStatus = ParticipantStatus.pending);
      if (mounted) {
        showDialog(context: context, builder: (_) => AlertDialog(
          backgroundColor: TAColor.surface,
          title: const Text('Request sent', style: TextStyle(color: TAColor.textPrimary)),
          content: const Text("You'll get a notification the moment the organiser accepts.", style: TextStyle(color: TAColor.textSecondary)),
          actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('OK'))],
        ));
      }
    } catch (_) {}
    setState(() => _isSubmitting = false);
  }

  Future<void> _showSafetySheet() async {
    final uid = AuthService.instance.currentUserId;
    if (uid == null || _activity == null) return;
    showModalBottomSheet(
      context: context,
      backgroundColor: TAColor.surface,
      builder: (_) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ListTile(
              leading: const Icon(Icons.flag_outlined, color: TAColor.danger),
              title: const Text('Report organiser', style: TextStyle(color: TAColor.danger)),
              onTap: () async {
                Navigator.pop(context);
                await SafetyService.instance.report(
                  reporterId: uid, reportedUserId: _activity!.organiserId,
                  activityId: _activity!.id, reason: 'Reported from activity detail',
                );
                _showConfirmation("Thanks — our team will review this.");
              },
            ),
            ListTile(
              leading: const Icon(Icons.block, color: TAColor.danger),
              title: const Text('Block organiser', style: TextStyle(color: TAColor.danger)),
              onTap: () async {
                Navigator.pop(context);
                await SafetyService.instance.block(uid, _activity!.organiserId);
                _showConfirmation("You won't see activities from this organiser again.");
              },
            ),
          ],
        ),
      ),
    );
  }

  void _showConfirmation(String message) {
    if (!mounted) return;
    showDialog(context: context, builder: (_) => AlertDialog(
      backgroundColor: TAColor.surface,
      content: Text(message, style: const TextStyle(color: TAColor.textPrimary)),
      actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('OK'))],
    ));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: TAColor.background,
      body: _isLoading
          ? const Center(child: CircularProgressIndicator(color: TAColor.primary))
          : _activity == null
              ? const Center(child: EmptyStateView(icon: Icons.error_outline, title: 'Something went wrong', message: "Couldn't load this activity."))
              : Stack(
                  children: [
                    SingleChildScrollView(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Stack(
                            children: [
                              Container(
                                height: 200,
                                decoration: const BoxDecoration(
                                  gradient: LinearGradient(colors: [TAColor.primaryTint, TAColor.surfaceHigh], begin: Alignment.topLeft, end: Alignment.bottomRight),
                                ),
                              ),
                              SafeArea(
                                child: Padding(
                                  padding: const EdgeInsets.all(16),
                                  child: GestureDetector(
                                    onTap: () => Navigator.pop(context),
                                    child: Container(
                                      width: 36, height: 36,
                                      decoration: BoxDecoration(color: Colors.white.withValues(alpha: 0.9), shape: BoxShape.circle),
                                      child: const Icon(Icons.arrow_back, size: 18),
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                          Padding(
                            padding: const EdgeInsets.all(TASpacing.lg),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Pill(text: _activity!.category),
                                const SizedBox(height: TASpacing.md),
                                Text(_activity!.title, style: const TextStyle(color: TAColor.textPrimary, fontSize: 21, fontWeight: FontWeight.bold)),
                                const SizedBox(height: TASpacing.md),
                                _infoRow(Icons.calendar_today, '${_activity!.friendlyDate} · ${_activity!.time}'),
                                _infoRow(Icons.location_on_outlined, _activity!.location),
                                _infoRow(Icons.people_outline, '${_activity!.acceptedCount} of ${_activity!.maxParticipants} spots filled'),
                                const SizedBox(height: TASpacing.md),
                                _organiserCard(),
                                const SizedBox(height: TASpacing.lg),
                                _goingSection(),
                                const SizedBox(height: TASpacing.lg),
                                Text(_activity!.description, style: const TextStyle(color: TAColor.textSecondary, fontSize: 13.5, height: 1.6)),
                                const SizedBox(height: 100),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                    Positioned(left: 0, right: 0, bottom: 0, child: _ctaBar()),
                  ],
                ),
    );
  }

  Widget _infoRow(IconData icon, String text) {
    return Padding(
      padding: const EdgeInsets.only(bottom: TASpacing.md),
      child: Row(
        children: [
          Container(
            width: 34, height: 34,
            decoration: BoxDecoration(color: TAColor.surface, borderRadius: BorderRadius.circular(10)),
            child: Icon(icon, size: 16, color: TAColor.primary),
          ),
          const SizedBox(width: TASpacing.md),
          Expanded(child: Text(text, style: const TextStyle(color: TAColor.textSecondary, fontSize: 13.5, fontWeight: FontWeight.w600))),
        ],
      ),
    );
  }

  Widget _organiserCard() {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(color: TAColor.surface, borderRadius: BorderRadius.circular(TARadius.md)),
      child: Row(
        children: [
          TrustRingAvatar(initials: _organiser?.initials ?? '?'),
          const SizedBox(width: TASpacing.md),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('Hosted by ${_organiser?.fullName ?? '—'}', style: const TextStyle(color: TAColor.textPrimary, fontSize: 14, fontWeight: FontWeight.bold)),
                const Text('Member of TagAlong', style: TextStyle(color: TAColor.textMuted, fontSize: 12)),
              ],
            ),
          ),
          IconButton(icon: const Icon(Icons.more_horiz, color: TAColor.textMuted), onPressed: _showSafetySheet),
        ],
      ),
    );
  }

  Widget _goingSection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text("Who's going", style: TextStyle(color: TAColor.textPrimary, fontSize: 13, fontWeight: FontWeight.bold)),
        const SizedBox(height: TASpacing.sm),
        Row(
          children: [
            AvatarStack(initials: _going.map((p) => p.initials).toList(), size: 30, maxShown: 4),
            const SizedBox(width: TASpacing.sm),
            Text('${_going.length} people going', style: const TextStyle(color: TAColor.textSecondary, fontSize: 12, fontWeight: FontWeight.w600)),
          ],
        ),
      ],
    );
  }

  Widget _ctaBar() {
    final activity = _activity!;
    final isOrganiser = AuthService.instance.currentUserId == activity.organiserId;
    return Container(
      padding: const EdgeInsets.all(TASpacing.lg),
      color: TAColor.background,
      child: SafeArea(
        top: false,
        child: _myStatus != null
            ? statusBadge(_myStatus!)
            : Column(
                children: [
                  PrimaryButton(
                    title: activity.spotsRemaining > 0 ? 'Request to join' : 'Join waitlist',
                    isLoading: _isSubmitting,
                    isDisabled: isOrganiser,
                    onPressed: _requestToJoin,
                  ),
                  const SizedBox(height: 6),
                  const Text('The organiser reviews and approves requests', style: TextStyle(color: TAColor.textMuted, fontSize: 11.5, fontWeight: FontWeight.w600)),
                ],
              ),
      ),
    );
  }
}
