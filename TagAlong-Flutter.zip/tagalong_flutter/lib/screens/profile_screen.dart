import 'package:flutter/material.dart';
import '../app_theme.dart';
import '../models.dart';
import '../services/auth_service.dart';
import '../services/profile_service.dart';
import '../services/safety_service.dart';
import '../widgets/components.dart';

class ProfileScreen extends StatefulWidget {
  final Profile profile;
  final ValueChanged<Profile> onProfileChanged;
  const ProfileScreen({super.key, required this.profile, required this.onProfileChanged});

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  int _hosted = 0;
  int _joined = 0;

  @override
  void initState() {
    super.initState();
    _loadStats();
  }

  Future<void> _loadStats() async {
    final uid = AuthService.instance.currentUserId;
    if (uid == null) return;
    final stats = await ProfileService.instance.fetchStats(uid);
    if (!mounted) return;
    setState(() { _hosted = stats.$1; _joined = stats.$2; });
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: SingleChildScrollView(
        padding: const EdgeInsets.all(TASpacing.xl),
        child: Column(
          children: [
            Row(mainAxisAlignment: MainAxisAlignment.end, children: [
              IconButton(
                icon: const Icon(Icons.settings, color: TAColor.textSecondary),
                onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const SettingsScreen())),
              ),
            ]),
            AvatarView(initials: widget.profile.initials, size: 84),
            const SizedBox(height: TASpacing.md),
            Text(widget.profile.fullName, style: const TextStyle(color: TAColor.textPrimary, fontSize: 19, fontWeight: FontWeight.bold)),
            if (widget.profile.location != null) ...[
              const SizedBox(height: 4),
              Text(widget.profile.location!, style: const TextStyle(color: TAColor.textMuted, fontSize: 12)),
            ],
            if (widget.profile.bio != null) ...[
              const SizedBox(height: 8),
              Text(widget.profile.bio!, textAlign: TextAlign.center, style: const TextStyle(color: TAColor.textSecondary, fontSize: 13)),
            ],
            const SizedBox(height: TASpacing.lg),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                _statColumn(_hosted, 'Hosted'),
                const SizedBox(width: TASpacing.xxl),
                _statColumn(_joined, 'Joined'),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _statColumn(int value, String label) {
    return Column(children: [
      Text('$value', style: const TextStyle(color: TAColor.textPrimary, fontSize: 20, fontWeight: FontWeight.bold)),
      Text(label, style: const TextStyle(color: TAColor.textMuted, fontSize: 12)),
    ]);
  }
}

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: TAColor.background,
      appBar: AppBar(backgroundColor: TAColor.background, title: const Text('Settings', style: TextStyle(color: TAColor.textPrimary))),
      body: ListView(
        children: [
          ListTile(
            title: const Text('Blocked users', style: TextStyle(color: TAColor.textPrimary)),
            trailing: const Icon(Icons.chevron_right, color: TAColor.textMuted),
            onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const BlockedUsersScreen())),
          ),
          const Divider(color: TAColor.divider, height: 1),
          ListTile(
            title: const Text('Log out', style: TextStyle(color: TAColor.danger)),
            onTap: () => AuthService.instance.signOut(),
          ),
        ],
      ),
    );
  }
}

class BlockedUsersScreen extends StatefulWidget {
  const BlockedUsersScreen({super.key});
  @override
  State<BlockedUsersScreen> createState() => _BlockedUsersScreenState();
}

class _BlockedUsersScreenState extends State<BlockedUsersScreen> {
  List<BlockedUser> _blocked = [];

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final uid = AuthService.instance.currentUserId;
    if (uid == null) return;
    final blocked = await SafetyService.instance.fetchBlockedUsers(uid);
    if (mounted) setState(() => _blocked = blocked);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: TAColor.background,
      appBar: AppBar(backgroundColor: TAColor.background, title: const Text('Blocked users', style: TextStyle(color: TAColor.textPrimary))),
      body: _blocked.isEmpty
          ? const Padding(
              padding: EdgeInsets.all(TASpacing.lg),
              child: Text("You haven't blocked anyone.", style: TextStyle(color: TAColor.textMuted, fontSize: 13)),
            )
          : ListView.builder(
              itemCount: _blocked.length,
              itemBuilder: (context, i) {
                final user = _blocked[i];
                return ListTile(
                  title: Text(user.fullName, style: const TextStyle(color: TAColor.textPrimary)),
                  trailing: TextButton(
                    onPressed: () async {
                      final uid = AuthService.instance.currentUserId;
                      if (uid == null) return;
                      await SafetyService.instance.unblock(uid, user.id);
                      _load();
                    },
                    child: const Text('Unblock', style: TextStyle(color: TAColor.primary, fontSize: 12)),
                  ),
                );
              },
            ),
    );
  }
}
