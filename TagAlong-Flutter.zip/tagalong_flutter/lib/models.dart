import 'package:intl/intl.dart';

enum ParticipantStatus { pending, accepted, rejected }

ParticipantStatus statusFromString(String s) {
  switch (s) {
    case 'accepted':
      return ParticipantStatus.accepted;
    case 'rejected':
      return ParticipantStatus.rejected;
    default:
      return ParticipantStatus.pending;
  }
}

String statusToString(ParticipantStatus s) => s.name;

class Profile {
  final String id;
  String fullName;
  String? bio;
  String? avatarUrl;
  String? location;
  List<String>? interests;

  Profile({required this.id, required this.fullName, this.bio, this.avatarUrl, this.location, this.interests});

  String get initials {
    final parts = fullName.trim().split(RegExp(r'\s+'));
    final letters = parts.take(2).map((p) => p.isNotEmpty ? p[0] : '').join();
    return letters.toUpperCase();
  }

  factory Profile.fromJson(Map<String, dynamic> json) => Profile(
        id: json['id'],
        fullName: json['full_name'] ?? '',
        bio: json['bio'],
        avatarUrl: json['avatar_url'],
        location: json['location'],
        interests: (json['interests'] as List?)?.map((e) => e.toString()).toList(),
      );

  Map<String, dynamic> toJson() => {
        'id': id,
        'full_name': fullName,
        'bio': bio,
        'avatar_url': avatarUrl,
        'location': location,
        'interests': interests ?? [],
      };
}

class Activity {
  final String id;
  final String organiserId;
  final String title;
  final String description;
  final String category;
  final String date; // yyyy-MM-dd
  final String time; // HH:mm
  final String location;
  final int maxParticipants;
  final int acceptedCount;

  Activity({
    required this.id,
    required this.organiserId,
    required this.title,
    required this.description,
    required this.category,
    required this.date,
    required this.time,
    required this.location,
    required this.maxParticipants,
    this.acceptedCount = 0,
  });

  int get spotsRemaining => (maxParticipants - acceptedCount).clamp(0, maxParticipants);

  String get friendlyDate {
    try {
      final d = DateTime.parse(date);
      return DateFormat('EEE, d MMM').format(d);
    } catch (_) {
      return date;
    }
  }

  String get scheduleSummary => '$friendlyDate · $time · $location';

  factory Activity.fromJson(Map<String, dynamic> json) => Activity(
        id: json['id'],
        organiserId: json['organiser_id'],
        title: json['title'] ?? '',
        description: json['description'] ?? '',
        category: json['category'] ?? '',
        date: json['date'].toString(),
        time: json['time'].toString().substring(0, 5),
        location: json['location'] ?? '',
        maxParticipants: json['max_participants'] ?? 0,
        acceptedCount: json['accepted_count'] ?? 0,
      );
}

const List<String> activityCategories = [
  'Sports', 'Outdoors', 'Food & Coffee', 'Games', 'Books', 'Wellness', 'Other',
];

class ActivityParticipant {
  final String id;
  final String activityId;
  final String userId;
  final ParticipantStatus status;
  final String? requesterName;
  final String? requesterInitials;
  final String? organiserId;

  ActivityParticipant({
    required this.id,
    required this.activityId,
    required this.userId,
    required this.status,
    this.requesterName,
    this.requesterInitials,
    this.organiserId,
  });

  factory ActivityParticipant.fromJson(Map<String, dynamic> json) => ActivityParticipant(
        id: json['id'],
        activityId: json['activity_id'],
        userId: json['user_id'],
        status: statusFromString(json['status']),
        requesterName: json['requesterName'],
        requesterInitials: json['requesterInitials'],
        organiserId: json['organiser_id'],
      );
}

class MyActivityRow {
  final Activity activity;
  final ParticipantStatus? myStatus;
  MyActivityRow({required this.activity, this.myStatus});
}

class BlockedUser {
  final String id;
  final String fullName;
  BlockedUser({required this.id, required this.fullName});

  factory BlockedUser.fromJson(Map<String, dynamic> json) =>
      BlockedUser(id: json['id'], fullName: json['full_name'] ?? '');
}
