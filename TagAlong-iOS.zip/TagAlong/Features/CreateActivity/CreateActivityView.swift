import SwiftUI

@MainActor
final class CreateActivityViewModel: ObservableObject {
    @Published var input = NewActivityInput()
    @Published var isSubmitting = false
    @Published var errorMessage: String?
    @Published var didPublish = false

    func publish(organiserId: UUID) async {
        guard input.isValid else {
            errorMessage = "Fill in a title, location, and a group size above 1."
            return
        }
        isSubmitting = true
        errorMessage = nil
        do {
            try await ActivityService.shared.createActivity(input, organiserId: organiserId)
            didPublish = true
            input = NewActivityInput()
        } catch {
            errorMessage = "Couldn't publish this activity. Please try again."
        }
        isSubmitting = false
    }
}

struct CreateActivityView: View {
    @EnvironmentObject var auth: AuthService
    @StateObject private var vm = CreateActivityViewModel()

    var body: some View {
        NavigationStack {
            ZStack {
                TAColor.background.ignoresSafeArea()
                ScrollView {
                    VStack(alignment: .leading, spacing: TASpacing.lg) {
                        TAField(label: "Title", placeholder: "Sunset badminton + chai", text: $vm.input.title)

                        VStack(alignment: .leading, spacing: 6) {
                            Text("Category").font(TAFont.body(12.5, weight: .semibold)).foregroundColor(TAColor.textSecondary)
                            Picker("Category", selection: $vm.input.category) {
                                ForEach(ActivityCategory.allCases) { cat in
                                    Text(cat.rawValue).tag(cat.rawValue)
                                }
                            }
                            .pickerStyle(.menu)
                            .tint(TAColor.textPrimary)
                            .padding(14)
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .background(TAColor.surface)
                            .clipShape(RoundedRectangle(cornerRadius: TARadius.sm))
                        }

                        HStack(spacing: TASpacing.md) {
                            dateField
                            timeField
                        }

                        TAField(label: "Location", placeholder: "Koramangala 5th Block", text: $vm.input.location)

                        Stepper("Max participants: \(vm.input.maxParticipants)", value: $vm.input.maxParticipants, in: 2...50)
                            .font(TAFont.body(13.5, weight: .semibold))
                            .foregroundColor(TAColor.textPrimary)
                            .padding(14)
                            .background(TAColor.surface)
                            .clipShape(RoundedRectangle(cornerRadius: TARadius.sm))

                        VStack(alignment: .leading, spacing: 6) {
                            Text("Description").font(TAFont.body(12.5, weight: .semibold)).foregroundColor(TAColor.textSecondary)
                            TextEditor(text: $vm.input.description)
                                .frame(height: 100)
                                .scrollContentBackground(.hidden)
                                .foregroundColor(TAColor.textPrimary)
                                .padding(10)
                                .background(TAColor.surface)
                                .clipShape(RoundedRectangle(cornerRadius: TARadius.sm))
                        }

                        if let error = vm.errorMessage {
                            Text(error).font(TAFont.caption).foregroundColor(TAColor.danger)
                        }

                        PrimaryButton(title: "Publish activity", isLoading: vm.isSubmitting) {
                            guard let uid = auth.currentUserId else { return }
                            Task { await vm.publish(organiserId: uid) }
                        }
                    }
                    .padding(TASpacing.lg)
                }
            }
            .navigationTitle("Host an activity")
            .alert("Activity published", isPresented: $vm.didPublish) {
                Button("OK", role: .cancel) {}
            } message: {
                Text("Your activity is live. You'll see join requests under My Activities.")
            }
        }
    }

    private var dateField: some View {
        VStack(alignment: .leading, spacing: 6) {
            Text("Date").font(TAFont.body(12.5, weight: .semibold)).foregroundColor(TAColor.textSecondary)
            DatePicker("", selection: $vm.input.date, displayedComponents: .date)
                .labelsHidden()
                .tint(TAColor.primary)
        }
    }

    private var timeField: some View {
        VStack(alignment: .leading, spacing: 6) {
            Text("Time").font(TAFont.body(12.5, weight: .semibold)).foregroundColor(TAColor.textSecondary)
            DatePicker("", selection: $vm.input.time, displayedComponents: .hourAndMinute)
                .labelsHidden()
                .tint(TAColor.primary)
        }
    }
}
