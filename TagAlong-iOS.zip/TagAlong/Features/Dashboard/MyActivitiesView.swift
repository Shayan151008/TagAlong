import SwiftUI

@MainActor
final class MyActivitiesViewModel: ObservableObject {
    @Published var hosted: [Activity] = []
    @Published var joinedRows: [MyActivityRow] = []
    @Published var pendingRows: [MyActivityRow] = []
    @Published var isLoading = false

    func load(userId: UUID) async {
        isLoading = true
        async let hostedTask = ActivityService.shared.fetchHosted(by: userId)
        async let requestsTask = ParticipantService.shared.myJoinedActivities(userId: userId)

        hosted = (try? await hostedTask) ?? []
        let requests = (try? await requestsTask) ?? []

        var joined: [MyActivityRow] = []
        var pending: [MyActivityRow] = []

        for request in requests {
            guard let activity = try? await ActivityService.shared.fetchActivity(id: request.activityId) else { continue }
            let row = MyActivityRow(activity: activity, myStatus: request.status)
            switch request.status {
            case .accepted: joined.append(row)
            case .pending: pending.append(row)
            case .rejected: break
            }
        }

        joinedRows = joined
        pendingRows = pending
        isLoading = false
    }
}

struct MyActivitiesView: View {
    @EnvironmentObject var auth: AuthService
    @StateObject private var vm = MyActivitiesViewModel()
    @State private var selectedTab = 0

    var body: some View {
        NavigationStack {
            VStack(spacing: TASpacing.lg) {
                Picker("", selection: $selectedTab) {
                    Text("Hosting").tag(0)
                    Text("Joined").tag(1)
                    Text("Pending").tag(2)
                }
                .pickerStyle(.segmented)
                .padding(.horizontal, TASpacing.lg)
                .padding(.top, TASpacing.sm)

                ScrollView {
                    LazyVStack(spacing: TASpacing.md) {
                        content
                    }
                    .padding(TASpacing.lg)
                }
            }
            .background(TAColor.background.ignoresSafeArea())
            .navigationTitle("My Activities")
            .task { if let uid = auth.currentUserId { await vm.load(userId: uid) } }
            .refreshable { if let uid = auth.currentUserId { await vm.load(userId: uid) } }
        }
    }

    @ViewBuilder
    private var content: some View {
        switch selectedTab {
        case 0:
            if vm.hosted.isEmpty {
                EmptyStateView(icon: "megaphone", title: "You're not hosting anything yet", message: "Create an activity and people nearby will be able to request to join.")
            } else {
                ForEach(vm.hosted) { activity in
                    NavigationLink {
                        JoinRequestsView()
                    } label: {
                        dashCard(activity: activity, trailing: AnyView(
                            Text("\(activity.acceptedCount ?? 0)/\(activity.maxParticipants) joined")
                                .font(TAFont.caption).foregroundColor(TAColor.textMuted)
                        ))
                    }
                    .buttonStyle(.plain)
                }
            }
        case 1:
            rows(vm.joinedRows, emptyIcon: "checkmark.circle", emptyTitle: "No confirmed plans yet", emptyMessage: "Activities you're accepted into will show up here.")
        default:
            rows(vm.pendingRows, emptyIcon: "hourglass", emptyTitle: "Nothing pending", emptyMessage: "Requests you send will show up here while you wait to hear back.")
        }
    }

    private func rows(_ rows: [MyActivityRow], emptyIcon: String, emptyTitle: String, emptyMessage: String) -> some View {
        Group {
            if rows.isEmpty {
                EmptyStateView(icon: emptyIcon, title: emptyTitle, message: emptyMessage)
            } else {
                ForEach(rows) { row in
                    NavigationLink(value: row.activity) {
                        dashCard(activity: row.activity, trailing: AnyView(
                            row.myStatus.map { ParticipantStatusStyle.badge(for: $0) }
                        ))
                    }
                    .buttonStyle(.plain)
                }
                .navigationDestination(for: Activity.self) { activity in
                    ActivityDetailView(activityId: activity.id)
                }
            }
        }
    }

    private func dashCard(activity: Activity, trailing: AnyView) -> some View {
        HStack(spacing: TASpacing.md) {
            RoundedRectangle(cornerRadius: 12)
                .fill(LinearGradient(colors: [TAColor.primaryTint, TAColor.surfaceHigh], startPoint: .top, endPoint: .bottom))
                .frame(width: 52, height: 52)

            VStack(alignment: .leading, spacing: 3) {
                Text(activity.title)
                    .font(TAFont.body(13.5, weight: .bold))
                    .foregroundColor(TAColor.textPrimary)
                Text(activity.scheduleSummary)
                    .font(TAFont.body(11.5))
                    .foregroundColor(TAColor.textMuted)
                trailing
            }

            Spacer()
        }
        .padding(14)
        .background(TAColor.surface)
        .clipShape(RoundedRectangle(cornerRadius: TARadius.md))
    }
}
