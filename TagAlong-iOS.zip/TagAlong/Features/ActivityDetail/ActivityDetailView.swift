import SwiftUI

@MainActor
final class ActivityDetailViewModel: ObservableObject {
    @Published var activity: Activity?
    @Published var organiser: Profile?
    @Published var going: [Profile] = []
    @Published var myStatus: ParticipantStatus?
    @Published var isLoading = false
    @Published var isSubmitting = false
    @Published var errorMessage: String?
    @Published var requestSent = false
    @Published var actionConfirmed: String?

    let activityId: UUID

    init(activityId: UUID) {
        self.activityId = activityId
    }

    func load(currentUserId: UUID?) async {
        isLoading = true
        do {
            let activity = try await ActivityService.shared.fetchActivity(id: activityId)
            self.activity = activity
            async let organiserTask = ProfileService.shared.fetchProfile(id: activity.organiserId)
            async let goingTask = ActivityService.shared.fetchGoing(activityId: activityId)
            self.organiser = try await organiserTask
            self.going = try await goingTask
            if let currentUserId {
                myStatus = try await ParticipantService.shared.myStatus(activityId: activityId, userId: currentUserId)
            }
        } catch {
            errorMessage = "Couldn't load this activity."
        }
        isLoading = false
    }

    func requestToJoin(userId: UUID) async {
        isSubmitting = true
        do {
            try await ParticipantService.shared.requestToJoin(activityId: activityId, userId: userId)
            myStatus = .pending
            requestSent = true
        } catch {
            errorMessage = "Couldn't send your request. Please try again."
        }
        isSubmitting = false
    }

    func reportOrganiser(reporterId: UUID) async {
        guard let organiserId = activity?.organiserId else { return }
        try? await SafetyService.shared.report(reporterId: reporterId, reportedUserId: organiserId, activityId: activityId, reason: "Reported from activity detail")
        actionConfirmed = "Thanks — our team will review this."
    }

    func blockOrganiser(blockerId: UUID) async {
        guard let organiserId = activity?.organiserId else { return }
        try? await SafetyService.shared.block(blockerId: blockerId, blockedId: organiserId)
        actionConfirmed = "You won't see activities from this organiser again."
    }
}

struct ActivityDetailView: View {
    @EnvironmentObject var auth: AuthService
    @StateObject private var vm: ActivityDetailViewModel
    @State private var showSafetySheet = false

    init(activityId: UUID) {
        _vm = StateObject(wrappedValue: ActivityDetailViewModel(activityId: activityId))
    }

    var body: some View {
        ZStack {
            TAColor.background.ignoresSafeArea()

            if let activity = vm.activity {
                ScrollView {
                    VStack(alignment: .leading, spacing: 0) {
                        LinearGradient(colors: [TAColor.primaryTint, TAColor.surfaceHigh], startPoint: .topLeading, endPoint: .bottomTrailing)
                            .frame(height: 200)

                        VStack(alignment: .leading, spacing: TASpacing.md) {
                            Pill(text: activity.category)

                            Text(activity.title)
                                .font(TAFont.display(21))
                                .foregroundColor(TAColor.textPrimary)

                            infoRow(icon: "calendar", text: "\(Activity.friendlyDate(activity.date)) · \(activity.time)")
                            infoRow(icon: "mappin.and.ellipse", text: activity.location)
                            infoRow(icon: "person.2.fill", text: "\(activity.acceptedCount ?? 0) of \(activity.maxParticipants) spots filled")

                            organiserCard

                            goingSection

                            Text(activity.description)
                                .font(TAFont.body(13.5))
                                .foregroundColor(TAColor.textSecondary)
                                .lineSpacing(5)
                                .padding(.top, TASpacing.sm)
                        }
                        .padding(TASpacing.lg)
                    }
                }

                VStack {
                    Spacer()
                    ctaBar(activity: activity)
                }
            } else if vm.isLoading {
                ProgressView().tint(TAColor.primary)
            } else if let error = vm.errorMessage {
                EmptyStateView(icon: "exclamationmark.triangle", title: "Something went wrong", message: error)
            }
        }
        .task { await vm.load(currentUserId: auth.currentUserId) }
        .alert("Request sent", isPresented: $vm.requestSent) {
            Button("OK", role: .cancel) {}
        } message: {
            Text("You'll get a notification the moment the organiser accepts.")
        }
        .alert(vm.actionConfirmed ?? "", isPresented: Binding(get: { vm.actionConfirmed != nil }, set: { if !$0 { vm.actionConfirmed = nil } })) {
            Button("OK", role: .cancel) {}
        }
        .confirmationDialog("Organiser options", isPresented: $showSafetySheet, titleVisibility: .visible) {
            Button("Report organiser", role: .destructive) {
                guard let uid = auth.currentUserId else { return }
                Task { await vm.reportOrganiser(reporterId: uid) }
            }
            Button("Block organiser", role: .destructive) {
                guard let uid = auth.currentUserId else { return }
                Task { await vm.blockOrganiser(blockerId: uid) }
            }
            Button("Cancel", role: .cancel) {}
        }
    }

    private func infoRow(icon: String, text: String) -> some View {
        HStack(spacing: TASpacing.md) {
            ZStack {
                RoundedRectangle(cornerRadius: 10).fill(TAColor.surface).frame(width: 34, height: 34)
                Image(systemName: icon).font(.system(size: 14)).foregroundColor(TAColor.primary)
            }
            Text(text).font(TAFont.body(13.5, weight: .semibold)).foregroundColor(TAColor.textSecondary)
        }
    }

    private var organiserCard: some View {
        HStack(spacing: TASpacing.md) {
            TrustRingAvatar(initials: vm.organiser?.initials ?? "?")
            VStack(alignment: .leading, spacing: 2) {
                Text("Hosted by \(vm.organiser?.fullName ?? "—")")
                    .font(TAFont.body(14, weight: .bold))
                    .foregroundColor(TAColor.textPrimary)
                Text("Member of TagAlong")
                    .font(TAFont.caption)
                    .foregroundColor(TAColor.textMuted)
            }
            Spacer()
            Button { showSafetySheet = true } label: {
                Image(systemName: "ellipsis")
                    .foregroundColor(TAColor.textMuted)
                    .padding(8)
            }
        }
        .padding(14)
        .background(TAColor.surface)
        .clipShape(RoundedRectangle(cornerRadius: TARadius.md))
    }

    private var goingSection: some View {
        VStack(alignment: .leading, spacing: TASpacing.sm) {
            Text("Who's going").font(TAFont.body(13, weight: .bold)).foregroundColor(TAColor.textPrimary)
            HStack(spacing: TASpacing.sm) {
                AvatarStack(initials: vm.going.map(\.initials), size: 30, maxShown: 4)
                Text("\(vm.going.count) people going")
                    .font(TAFont.body(12, weight: .semibold))
                    .foregroundColor(TAColor.textSecondary)
            }
        }
    }

    private func ctaBar(activity: Activity) -> some View {
        VStack(spacing: 6) {
            if let status = vm.myStatus {
                ParticipantStatusStyle.badge(for: status)
                    .frame(maxWidth: .infinity)
            } else {
                PrimaryButton(
                    title: activity.spotsRemaining > 0 ? "Request to join" : "Join waitlist",
                    isLoading: vm.isSubmitting,
                    isDisabled: auth.currentUserId == activity.organiserId
                ) {
                    guard let uid = auth.currentUserId else { return }
                    Task { await vm.requestToJoin(userId: uid) }
                }
                Text("The organiser reviews and approves requests")
                    .font(TAFont.caption)
                    .foregroundColor(TAColor.textMuted)
            }
        }
        .padding(TASpacing.lg)
        .background(TAColor.background.opacity(0.98))
    }
}
