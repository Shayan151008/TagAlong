import SwiftUI

struct ProfileSetupView: View {
    let onComplete: (Profile) -> Void

    @EnvironmentObject var auth: AuthService
    @State private var fullName = ""
    @State private var bio = ""
    @State private var location = ""
    @State private var isLoading = false
    @State private var errorMessage: String?

    var body: some View {
        ZStack {
            TAColor.background.ignoresSafeArea()
            ScrollView {
                VStack(alignment: .leading, spacing: TASpacing.lg) {
                    VStack(alignment: .leading, spacing: 4) {
                        Text("Almost there")
                            .font(TAFont.screenTitle)
                            .foregroundColor(TAColor.textPrimary)
                        Text("Let's set up your profile")
                            .font(TAFont.body(14))
                            .foregroundColor(TAColor.textSecondary)
                    }

                    HStack {
                        Spacer()
                        ZStack {
                            Circle().fill(TAColor.surface).frame(width: 88, height: 88)
                            Image(systemName: "camera.fill").foregroundColor(TAColor.textMuted)
                        }
                        Spacer()
                    }

                    TAField(label: "Full name", placeholder: "Your name", text: $fullName)
                    TAField(label: "Bio", placeholder: "Love sports, coffee and meeting new people", text: $bio)
                    TAField(label: "Location", placeholder: "Bengaluru, India", text: $location)

                    if let errorMessage {
                        Text(errorMessage).font(TAFont.caption).foregroundColor(TAColor.danger)
                    }

                    PrimaryButton(title: "Continue", isLoading: isLoading, isDisabled: fullName.trimmingCharacters(in: .whitespaces).isEmpty) {
                        Task { await save() }
                    }
                }
                .padding(TASpacing.xl)
            }
        }
    }

    private func save() async {
        guard let uid = auth.currentUserId else { return }
        isLoading = true
        errorMessage = nil
        let profile = Profile(id: uid, fullName: fullName, bio: bio.isEmpty ? nil : bio, avatarUrl: nil, location: location.isEmpty ? nil : location, interests: [])
        do {
            try await ProfileService.shared.upsertProfile(profile)
            onComplete(profile)
        } catch {
            errorMessage = "Couldn't save your profile. Please try again."
        }
        isLoading = false
    }
}
