import SwiftUI

@MainActor
final class HomeFeedViewModel: ObservableObject {
    @Published var activities: [Activity] = []
    @Published var selectedCategory: String = "All"
    @Published var searchText: String = ""
    @Published var isLoading = false
    @Published var errorMessage: String?

    let categories = ["All"] + ActivityCategory.allCases.map(\.rawValue)

    func load() async {
        isLoading = true
        errorMessage = nil
        do {
            activities = try await ActivityService.shared.fetchNearby(category: selectedCategory)
        } catch {
            errorMessage = "Couldn't load activities. Pull to refresh to try again."
        }
        isLoading = false
    }

    var filtered: [Activity] {
        guard !searchText.isEmpty else { return activities }
        return activities.filter { $0.title.localizedCaseInsensitiveContains(searchText) }
    }
}

struct HomeFeedView: View {
    @StateObject private var vm = HomeFeedViewModel()

    var body: some View {
        NavigationStack {
            ZStack {
                TAColor.background.ignoresSafeArea()
                ScrollView {
                    VStack(alignment: .leading, spacing: TASpacing.lg) {
                        searchBar

                        ScrollView(.horizontal, showsIndicators: false) {
                            HStack(spacing: TASpacing.sm) {
                                ForEach(vm.categories, id: \.self) { cat in
                                    categoryChip(cat)
                                }
                            }
                        }

                        if vm.isLoading {
                            ProgressView().tint(TAColor.primary).frame(maxWidth: .infinity).padding(.top, 40)
                        } else if vm.filtered.isEmpty {
                            EmptyStateView(icon: "figure.walk", title: "Nothing nearby yet", message: "Try a different category, or be the first to host something here.")
                        } else {
                            ForEach(vm.filtered) { activity in
                                NavigationLink(value: activity) {
                                    ActivityCardView(activity: activity, goingInitials: ["R", "S", "A"], goingCount: activity.acceptedCount ?? 0)
                                }
                                .buttonStyle(.plain)
                            }
                        }
                    }
                    .padding(TASpacing.lg)
                }
            }
            .navigationTitle("Explore")
            .navigationDestination(for: Activity.self) { activity in
                ActivityDetailView(activityId: activity.id)
            }
            .task { await vm.load() }
            .refreshable { await vm.load() }
            .onChange(of: vm.selectedCategory) { _, _ in Task { await vm.load() } }
        }
    }

    private var searchBar: some View {
        HStack(spacing: TASpacing.sm) {
            Image(systemName: "magnifyingglass").foregroundColor(TAColor.textMuted)
            TextField("Search activities near you", text: $vm.searchText)
                .foregroundColor(TAColor.textPrimary)
        }
        .padding(14)
        .background(TAColor.surface)
        .clipShape(Capsule())
    }

    private func categoryChip(_ category: String) -> some View {
        let isActive = vm.selectedCategory == category
        return Text(category)
            .font(TAFont.body(12.5, weight: .semibold))
            .foregroundColor(isActive ? .white : TAColor.textSecondary)
            .padding(.horizontal, 14)
            .padding(.vertical, 9)
            .background(isActive ? AnyShapeStyle(TAColor.primaryGradient) : AnyShapeStyle(TAColor.surface))
            .clipShape(Capsule())
            .onTapGesture { vm.selectedCategory = category }
    }
}

// Enables NavigationLink(value:) to Activity. Equatable is already synthesized
// on the Activity struct (see Models.swift), so only hashing needs adding here.
extension Activity: Hashable {
    func hash(into hasher: inout Hasher) { hasher.combine(id) }
}
