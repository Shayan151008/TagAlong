import SwiftUI

@MainActor
final class ProfileViewModel: ObservableObject {
    @Published var hostedCount = 0
    @Published var joinedCount = 0

    func loadStats(userId: UUID) async {
        if let stats = try? await ProfileService.shared.fetchStats(userId: userId) {
            hostedCount = stats.hosted
            joinedCount = stats.joined
        }
    }
}

struct ProfileView: View {
    @EnvironmentObject var auth: AuthService
    @Binding var profile: Profile
    @StateObject private var vm = ProfileViewModel()
    @State private var showSettings = false

    var body: some View {
        NavigationStack {
            ZStack {
                TAColor.background.ignoresSafeArea()
                ScrollView {
                    VStack(spacing: TASpacing.lg) {
                        AvatarView(initials: profile.initials, size: 84)

                        VStack(spacing: 4) {
                            Text(profile.fullName).font(TAFont.display(19)).foregroundColor(TAColor.textPrimary)
                            if let location = profile.location {
                                Label(location, systemImage: "mappin.circle.fill")
                                    .font(TAFont.caption)
                                    .foregroundColor(TAColor.textMuted)
                            }
                            if let bio = profile.bio {
                                Text(bio)
                                    .font(TAFont.body(13))
                                    .foregroundColor(TAColor.textSecondary)
                                    .multilineTextAlignment(.center)
                                    .padding(.top, 4)
                            }
                        }

                        HStack(spacing: TASpacing.xxl) {
                            statColumn(value: vm.hostedCount, label: "Hosted")
                            statColumn(value: vm.joinedCount, label: "Joined")
                        }
                        .padding(.vertical, TASpacing.md)
                    }
                    .padding(TASpacing.xl)
                }
            }
            .navigationTitle("Profile")
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Button { showSettings = true } label: {
                        Image(systemName: "gearshape.fill").foregroundColor(TAColor.textSecondary)
                    }
                }
            }
            .sheet(isPresented: $showSettings) { SettingsView() }
            .task { if let uid = auth.currentUserId { await vm.loadStats(userId: uid) } }
        }
    }

    private func statColumn(value: Int, label: String) -> some View {
        VStack(spacing: 2) {
            Text("\(value)").font(TAFont.display(20)).foregroundColor(TAColor.textPrimary)
            Text(label).font(TAFont.caption).foregroundColor(TAColor.textMuted)
        }
    }
}

struct SettingsView: View {
    @EnvironmentObject var auth: AuthService
    @Environment(\.dismiss) private var dismiss
    @State private var blockedUsers: [BlockedUser] = []

    var body: some View {
        NavigationStack {
            ZStack {
                TAColor.background.ignoresSafeArea()
                List {
                    Section {
                        NavigationLink("Blocked users") {
                            blockedUsersList
                        }
                    }
                    .listRowBackground(TAColor.surface)

                    Section {
                        Button(role: .destructive) {
                            Task { try? await auth.signOut() }
                        } label: {
                            Text("Log out").foregroundColor(TAColor.danger)
                        }
                    }
                    .listRowBackground(TAColor.surface)
                }
                .scrollContentBackground(.hidden)
            }
            .navigationTitle("Settings")
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Button("Done") { dismiss() }
                }
            }
        }
    }

    private var blockedUsersList: some View {
        List {
            if blockedUsers.isEmpty {
                Text("You haven't blocked anyone.")
                    .font(TAFont.body(13))
                    .foregroundColor(TAColor.textMuted)
                    .listRowBackground(TAColor.surface)
            } else {
                ForEach(blockedUsers) { user in
                    HStack {
                        Text(user.fullName).foregroundColor(TAColor.textPrimary)
                        Spacer()
                        Button("Unblock") {
                            Task {
                                guard let uid = auth.currentUserId else { return }
                                try? await SafetyService.shared.unblock(blockerId: uid, blockedId: user.id)
                                await loadBlocked()
                            }
                        }
                        .font(TAFont.caption)
                        .foregroundColor(TAColor.primary)
                    }
                    .listRowBackground(TAColor.surface)
                }
            }
        }
        .scrollContentBackground(.hidden)
        .background(TAColor.background)
        .navigationTitle("Blocked users")
        .task { await loadBlocked() }
    }

    private func loadBlocked() async {
        guard let uid = auth.currentUserId else { return }
        blockedUsers = (try? await SafetyService.shared.fetchBlockedUsers(blockerId: uid)) ?? []
    }
}
