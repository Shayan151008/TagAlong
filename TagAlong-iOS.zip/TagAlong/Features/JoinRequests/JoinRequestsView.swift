import SwiftUI

@MainActor
final class JoinRequestsViewModel: ObservableObject {
    @Published var pending: [ActivityParticipant] = []
    @Published var accepted: [ActivityParticipant] = []
    @Published var isLoading = false
    @Published var respondingId: UUID?

    func load(organiserId: UUID) async {
        isLoading = true
        async let pendingTask = ParticipantService.shared.requestsForHost(organiserId: organiserId, status: .pending)
        async let acceptedTask = ParticipantService.shared.requestsForHost(organiserId: organiserId, status: .accepted)
        pending = (try? await pendingTask) ?? []
        accepted = (try? await acceptedTask) ?? []
        isLoading = false
    }

    func respond(_ request: ActivityParticipant, accept: Bool, organiserId: UUID) async {
        respondingId = request.id
        try? await ParticipantService.shared.respond(requestId: request.id, accept: accept)
        await load(organiserId: organiserId)
        respondingId = nil
    }
}

struct JoinRequestsView: View {
    @EnvironmentObject var auth: AuthService
    @StateObject private var vm = JoinRequestsViewModel()
    @State private var selectedTab = 0

    var body: some View {
        VStack(spacing: TASpacing.lg) {
            Picker("", selection: $selectedTab) {
                Text("Pending").tag(0)
                Text("Approved").tag(1)
            }
            .pickerStyle(.segmented)

            ScrollView {
                LazyVStack(spacing: TASpacing.md) {
                    let list = selectedTab == 0 ? vm.pending : vm.accepted
                    if list.isEmpty {
                        EmptyStateView(
                            icon: selectedTab == 0 ? "tray" : "checkmark.circle",
                            title: selectedTab == 0 ? "No pending requests" : "No approved members yet",
                            message: selectedTab == 0 ? "New requests to join your activities will show up here." : "Approve a request to see it here."
                        )
                    } else {
                        ForEach(list) { request in
                            requestRow(request)
                        }
                    }
                }
            }
        }
        .padding(TASpacing.lg)
        .background(TAColor.background.ignoresSafeArea())
        .task { if let uid = auth.currentUserId { await vm.load(organiserId: uid) } }
    }

    private func requestRow(_ request: ActivityParticipant) -> some View {
        HStack(spacing: TASpacing.md) {
            AvatarView(initials: request.requesterInitials ?? "?", size: 40)
            VStack(alignment: .leading, spacing: 2) {
                Text(request.requesterName ?? "Someone")
                    .font(TAFont.body(13.5, weight: .bold))
                    .foregroundColor(TAColor.textPrimary)
                Text("Requested to join")
                    .font(TAFont.caption)
                    .foregroundColor(TAColor.textMuted)
            }
            Spacer()

            if request.status == .pending {
                if vm.respondingId == request.id {
                    ProgressView().tint(TAColor.primary)
                } else {
                    Button {
                        guard let uid = auth.currentUserId else { return }
                        Task { await vm.respond(request, accept: false, organiserId: uid) }
                    } label: {
                        Image(systemName: "xmark")
                            .foregroundColor(TAColor.danger)
                            .padding(8)
                            .background(TAColor.dangerTint)
                            .clipShape(Circle())
                    }
                    Button {
                        guard let uid = auth.currentUserId else { return }
                        Task { await vm.respond(request, accept: true, organiserId: uid) }
                    } label: {
                        Image(systemName: "checkmark")
                            .foregroundColor(TAColor.success)
                            .padding(8)
                            .background(TAColor.successTint)
                            .clipShape(Circle())
                    }
                }
            } else {
                ParticipantStatusStyle.badge(for: request.status)
            }
        }
        .padding(14)
        .background(TAColor.surface)
        .clipShape(RoundedRectangle(cornerRadius: TARadius.md))
    }
}
