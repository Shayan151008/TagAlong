import Foundation

/// Fill these in from your Supabase project settings (Project Settings > API).
/// For a real build, move these into an .xcconfig / environment-based setup
/// instead of hardcoding — never commit the service_role key into the app.
enum SupabaseConfig {
    static let url = URL(string: "https://YOUR_PROJECT_REF.supabase.co")!
    static let anonKey = "YOUR_SUPABASE_ANON_KEY"
}
