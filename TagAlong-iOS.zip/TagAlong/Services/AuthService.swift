import Foundation
import Supabase

@MainActor
final class AuthService: ObservableObject {
    static let shared = AuthService()

    @Published var session: Session?
    @Published var isLoading = true

    private var client: SupabaseClient { SupabaseManager.shared.client }

    private init() {
        Task { await restoreSession() }
    }

    var currentUserId: UUID? { session?.user.id }
    var isAuthenticated: Bool { session != nil }

    func restoreSession() async {
        isLoading = true
        do {
            session = try await client.auth.session
        } catch {
            session = nil
        }
        isLoading = false
        listenForAuthChanges()
    }

    private func listenForAuthChanges() {
        Task {
            for await state in client.auth.authStateChanges {
                await MainActor.run {
                    self.session = state.session
                }
            }
        }
    }

    func signUp(email: String, password: String) async throws {
        let response = try await client.auth.signUp(email: email, password: password)
        session = response.session
    }

    func signIn(email: String, password: String) async throws {
        session = try await client.auth.signIn(email: email, password: password)
    }

    func signOut() async throws {
        try await client.auth.signOut()
        session = nil
    }
}
