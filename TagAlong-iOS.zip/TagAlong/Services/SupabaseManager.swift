import Foundation
import Supabase

/// Single shared Supabase client for the app.
/// Add the Supabase Swift package first: https://github.com/supabase/supabase-swift
final class SupabaseManager {
    static let shared = SupabaseManager()

    let client: SupabaseClient

    private init() {
        client = SupabaseClient(
            supabaseURL: SupabaseConfig.url,
            supabaseKey: SupabaseConfig.anonKey
        )
    }
}
