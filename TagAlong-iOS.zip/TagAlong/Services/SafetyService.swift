import Foundation
import Supabase

final class SafetyService {
    static let shared = SafetyService()
    private var client: SupabaseClient { SupabaseManager.shared.client }

    func report(reporterId: UUID, reportedUserId: UUID, activityId: UUID?, reason: String) async throws {
        let report = Report(reporterId: reporterId, reportedUserId: reportedUserId, activityId: activityId, reason: reason)
        try await client.from("reports").insert(report).execute()
    }

    func block(blockerId: UUID, blockedId: UUID) async throws {
        let payload: [String: AnyJSON] = [
            "blocker_id": .string(blockerId.uuidString),
            "blocked_id": .string(blockedId.uuidString)
        ]
        try await client.from("blocks").insert(payload).execute()
    }

    func unblock(blockerId: UUID, blockedId: UUID) async throws {
        try await client
            .from("blocks")
            .delete()
            .eq("blocker_id", value: blockerId)
            .eq("blocked_id", value: blockedId)
            .execute()
    }

    /// Requires the blocked_users_with_profile view — see schema.sql
    func fetchBlockedUsers(blockerId: UUID) async throws -> [BlockedUser] {
        try await client
            .from("blocked_users_with_profile")
            .select()
            .eq("blocker_id", value: blockerId)
            .execute()
            .value
    }
}
