import Foundation
import Supabase

final class ProfileService {
    static let shared = ProfileService()
    private var client: SupabaseClient { SupabaseManager.shared.client }

    func fetchProfile(id: UUID) async throws -> Profile? {
        try await client
            .from("profiles")
            .select()
            .eq("id", value: id)
            .single()
            .execute()
            .value
    }

    func upsertProfile(_ profile: Profile) async throws {
        try await client
            .from("profiles")
            .upsert(profile)
            .execute()
    }

    func fetchStats(userId: UUID) async throws -> (hosted: Int, joined: Int) {
        let hosted: [Activity] = try await client
            .from("activities")
            .select()
            .eq("organiser_id", value: userId)
            .execute()
            .value

        let joined: [ActivityParticipant] = try await client
            .from("activity_participants")
            .select()
            .eq("user_id", value: userId)
            .eq("status", value: ParticipantStatus.accepted.rawValue)
            .execute()
            .value

        return (hosted.count, joined.count)
    }
}
