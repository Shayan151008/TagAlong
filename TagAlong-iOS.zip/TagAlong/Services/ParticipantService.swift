import Foundation
import Supabase

final class ParticipantService {
    static let shared = ParticipantService()
    private var client: SupabaseClient { SupabaseManager.shared.client }

    func requestToJoin(activityId: UUID, userId: UUID) async throws {
        let payload: [String: AnyJSON] = [
            "activity_id": .string(activityId.uuidString),
            "user_id": .string(userId.uuidString),
            "status": .string(ParticipantStatus.pending.rawValue)
        ]
        try await client.from("activity_participants").insert(payload).execute()
    }

    func myStatus(activityId: UUID, userId: UUID) async throws -> ParticipantStatus? {
        let rows: [ActivityParticipant] = try await client
            .from("activity_participants")
            .select()
            .eq("activity_id", value: activityId)
            .eq("user_id", value: userId)
            .execute()
            .value
        return rows.first?.status
    }

    /// All join requests for activities the given user organises.
    /// Requires the participants_with_requester view — see schema.sql
    func requestsForHost(organiserId: UUID, status: ParticipantStatus? = nil) async throws -> [ActivityParticipant] {
        var query = client
            .from("participants_with_requester")
            .select()
            .eq("organiser_id", value: organiserId)

        if let status {
            query = query.eq("status", value: status.rawValue)
        }

        return try await query
            .order("requested_at", ascending: false)
            .execute()
            .value
    }

    func respond(requestId: UUID, accept: Bool) async throws {
        let payload: [String: AnyJSON] = [
            "status": .string(accept ? ParticipantStatus.accepted.rawValue : ParticipantStatus.rejected.rawValue),
            "responded_at": .string(ISO8601DateFormatter().string(from: Date()))
        ]
        try await client
            .from("activity_participants")
            .update(payload)
            .eq("id", value: requestId)
            .execute()
    }

    /// Activities the current user has requested/joined, for the dashboard.
    func myJoinedActivities(userId: UUID) async throws -> [ActivityParticipant] {
        try await client
            .from("activity_participants")
            .select()
            .eq("user_id", value: userId)
            .order("requested_at", ascending: false)
            .execute()
            .value
    }
}
