import SwiftUI

struct RootView: View {
    @EnvironmentObject var auth: AuthService
    @State private var profile: Profile?
    @State private var checkingProfile = false

    var body: some View {
        Group {
            if auth.isLoading {
                SplashView()
            } else if !auth.isAuthenticated {
                WelcomeView()
            } else if checkingProfile {
                SplashView()
            } else if profile == nil {
                ProfileSetupView(onComplete: { profile = $0 })
            } else {
                MainTabView(profile: $profile)
            }
        }
        .task(id: auth.currentUserId) {
            guard let uid = auth.currentUserId else { return }
            checkingProfile = true
            profile = try? await ProfileService.shared.fetchProfile(id: uid)
            checkingProfile = false
        }
    }
}

struct SplashView: View {
    var body: some View {
        ZStack {
            TAColor.background.ignoresSafeArea()
            VStack(spacing: TASpacing.md) {
                RoundedRectangle(cornerRadius: 20)
                    .fill(TAColor.primaryGradient)
                    .frame(width: 64, height: 64)
                    .overlay(Image(systemName: "person.2.fill").foregroundColor(.white).font(.system(size: 26)))
                Text("TagAlong")
                    .font(TAFont.display(24))
                    .foregroundColor(.white)
            }
        }
    }
}

struct MainTabView: View {
    @Binding var profile: Profile?

    var body: some View {
        TabView {
            HomeFeedView()
                .tabItem { Label("Explore", systemImage: "safari") }

            CreateActivityView()
                .tabItem { Label("Host", systemImage: "plus.circle.fill") }

            MyActivitiesView()
                .tabItem { Label("My Activities", systemImage: "calendar") }

            if let profile {
                ProfileView(profile: Binding(get: { profile }, set: { self.profile = $0 }))
                    .tabItem { Label("Profile", systemImage: "person.circle") }
            }
        }
        .tint(TAColor.primary)
    }
}
