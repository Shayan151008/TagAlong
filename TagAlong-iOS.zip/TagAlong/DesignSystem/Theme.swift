import SwiftUI

// MARK: - Color hex helper

extension Color {
    init(hex: String) {
        let scanner = Scanner(string: hex.trimmingCharacters(in: .whitespacesAndNewlines))
        var rgb: UInt64 = 0
        scanner.scanHexInt64(&rgb)
        let r = Double((rgb & 0xFF0000) >> 16) / 255
        let g = Double((rgb & 0x00FF00) >> 8) / 255
        let b = Double(rgb & 0x0000FF) / 255
        self.init(red: r, green: g, blue: b)
    }
}

// MARK: - TagAlong dark/violet design system

enum TAColor {
    // Backgrounds
    static let background = Color(hex: "12101C")
    static let backgroundElevated = Color(hex: "1A1729")
    static let surface = Color(hex: "1E1B2E")
    static let surfaceHigh = Color(hex: "252140")

    // Primary accent (violet)
    static let primary = Color(hex: "7C6FF0")
    static let primaryDark = Color(hex: "5B4FD6")
    static let primaryTint = Color(hex: "2A2550")

    // Text
    static let textPrimary = Color.white
    static let textSecondary = Color(hex: "B4AFC7")
    static let textMuted = Color(hex: "716C87")

    // Status
    static let success = Color(hex: "4ADE80")
    static let successTint = Color(hex: "1B3327")
    static let warning = Color(hex: "F5B454")
    static let warningTint = Color(hex: "332A18")
    static let danger = Color(hex: "F87171")
    static let dangerTint = Color(hex: "3A1E1E")

    static let divider = Color(hex: "2B2740")

    static let primaryGradient = LinearGradient(
        colors: [primary, primaryDark],
        startPoint: .topLeading,
        endPoint: .bottomTrailing
    )
}

enum TAFont {
    static func display(_ size: CGFloat, weight: Font.Weight = .bold) -> Font {
        .system(size: size, weight: weight, design: .rounded)
    }
    static func body(_ size: CGFloat, weight: Font.Weight = .regular) -> Font {
        .system(size: size, weight: weight, design: .default)
    }

    static let screenTitle = display(24, weight: .bold)
    static let cardTitle = body(15.5, weight: .bold)
    static let sectionLabel = body(12, weight: .bold)
    static let caption = body(12, weight: .medium)
    static let subtitle = body(14, weight: .semibold)
}

enum TASpacing {
    static let xs: CGFloat = 4
    static let sm: CGFloat = 8
    static let md: CGFloat = 12
    static let lg: CGFloat = 16
    static let xl: CGFloat = 24
    static let xxl: CGFloat = 32
}

enum TARadius {
    static let sm: CGFloat = 12
    static let md: CGFloat = 16
    static let lg: CGFloat = 24
    static let pill: CGFloat = 100
}
